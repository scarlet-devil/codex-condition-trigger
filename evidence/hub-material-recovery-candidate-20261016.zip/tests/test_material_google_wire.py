"""Exercise the production Google adapter with synthetic HTTP, never credentials."""
import base64
import hashlib
import json
import unittest
from unittest import mock
from types import SimpleNamespace
from drive_exchange_local_hub import HubError, canonical_json_bytes
from drive_exchange_local_hub.google_drive import GoogleDriveAdapter, DRIVE_FILE_SCOPE, _default_http_request


class MemoryCredential:
    def read(self, target):
        return canonical_json_bytes(dict(schema_version='drive-exchange-google-credential-v1',
            access_token='fixture', refresh_token='fixture', scope=DRIVE_FILE_SCOPE, token_type='Bearer'))


class Wire:
    def __init__(self):
        self.calls=[]; self.object=None; self.drop=False; self.conflict=False; self.denied=False
    def __call__(self, **request):
        self.calls.append(request); url=request['url']; method=request['method']
        def reply(status, body):
            return SimpleNamespace(status=status,body=body if isinstance(body,bytes) else canonical_json_bytes(body))
        if '/about?' in url: return reply(200,{'user':{'permissionId':'fixture'}})
        if '/generateIds?' in url: return reply(200,{'ids':['reserved-file']})
        if method=='POST':
            # Parse real multipart metadata and payload, not an adapter stub.
            parts=request['body'].split(b'\r\n\r\n')
            metadata=json.loads(parts[1].split(b'\r\n--')[0]); body=parts[2].split(b'\r\n--')[0]
            assert metadata['id']=='reserved-file'
            self.object=dict(metadata,trashed=False); self.content=body
            if self.drop: raise TimeoutError('synthetic response loss after creation')
            return reply(409 if self.conflict else 200,{'id':'reserved-file'})
        assert '/files/reserved-file?' in url
        if self.denied: return reply(403,{})
        if self.object is None: return reply(404,{})
        return reply(200,self.content if 'alt=media' in url else self.object)


class GoogleWireTests(unittest.TestCase):
    def setUp(self):
        self.wire=Wire(); self.adapter=GoogleDriveAdapter(client_id='fixture.apps.googleusercontent.com',
            client_secret='fixture',credential_store=MemoryCredential(),http_request=self.wire)
        self.body=b'synthetic payload'; self.d=dict(name='canary.txt',parent_id='folder',key='a'*64+':0',
            sha256=hashlib.sha256(self.body).hexdigest(),size=len(self.body))
    def call(self,action):
        return self.adapter.material_action(action,'google-drive:fixture','reserved-file',self.d,self.body)
    def test_preallocated_id_and_raw_bytes(self):
        self.assertEqual(self.adapter.reserve_material_id('google-drive:fixture'),'reserved-file')
        self.assertEqual(self.call('upload')['id'],'reserved-file')
        self.assertEqual(base64.b64decode(self.call('readback')['content_base64']),self.body)
        self.assertEqual(sum(c['method']=='POST' for c in self.wire.calls),1)
    def test_lost_post_response_reconciles_without_second_create(self):
        self.wire.drop=True
        with self.assertRaises(TimeoutError): self.call('upload')
        self.assertEqual(self.call('lookup')['id'],'reserved-file')
        self.call('upload')
        self.assertEqual(sum(c['method']=='POST' for c in self.wire.calls),1)
    def test_conflict_is_resolved_by_exact_id_read(self):
        self.wire.conflict=True
        self.assertEqual(self.call('upload')['id'],'reserved-file')
        self.assertEqual(self.wire.calls[-1]['method'],'GET')
    def test_forbidden_read_never_grants_create(self):
        self.wire.denied=True
        with self.assertRaises(HubError): self.call('upload')
        self.assertFalse(any(c['method']=='POST' for c in self.wire.calls))
    def test_oversize_media_rejected_before_base64(self):
        self.call('upload');self.wire.content=self.body+b'extra'
        with self.assertRaisesRegex(HubError,'MATERIAL_READBACK_LIMIT'):self.call('readback')
    def test_http_stream_is_bounded_before_allocation(self):
        stream=mock.MagicMock();stream.__enter__.return_value=stream
        stream.status=200;stream.headers={};stream.read.return_value=b'xx'
        with mock.patch('urllib.request.urlopen',return_value=stream):
            with self.assertRaisesRegex(HubError,'MATERIAL_READBACK_LIMIT'):
                _default_http_request(method='GET',url='https://www.googleapis.com/drive/v3/files/id?alt=media',
                                      headers={},max_response_bytes=1)
        stream.read.assert_called_once_with(2)

