import base64, hashlib, json, struct, tempfile, unittest, gc
from pathlib import Path
from drive_exchange_local_hub import HubStore, LocalHub, FakeDriveConnector, canonical_json_bytes, project_identity_for_root, HubError

class Provider:
    def __init__(self): self.objects={};self.reserved=0;self.creates=0;self.drop=False
    def reserve_material_id(self,identity):self.reserved+=1;return 'reserved-'+str(self.reserved)
    def material_action(self,action,identity,remote_id,descriptor,body):
        if action=='upload' and remote_id not in self.objects:
            self.creates+=1;self.objects[remote_id]=(dict(descriptor),bytes(body))
            if self.drop:raise TimeoutError('response deliberately lost')
        if remote_id not in self.objects:return None
        d,b=self.objects[remote_id]
        return dict(id=remote_id,name=d['name'],parents=[d['parent_id']],trashed=False,
                    appProperties={'condition_key':d['key'],'source_sha256':d['sha256']},
                    content_base64=base64.b64encode(b).decode() if action=='readback' else None)

class RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.addCleanup(gc.collect);self.root=Path(self.tmp.name)
        (self.root/'.drive-exchange').mkdir();(self.root/'.drive-exchange/project.json').write_text(json.dumps({'project_id':'synthetic'}))
        self.store=HubStore(self.root/'hub.sqlite');self.store.register_project(root=self.root,display_name='Synthetic')
        fake=FakeDriveConnector(folders={'folder'});self.store.bind_route(project_id='synthetic',route_name='standard',folder_id='folder',verification=fake.verify_folder('folder'))
        self.provider=Provider();self.hub=LocalHub(store=self.store,connector=self.provider)
        self.body=b'synthetic recovery\n';sha=hashlib.sha256(self.body).hexdigest()
        self.desc={'key':'a'*64+':0','batch_id':'b'*64,'manifest_sha256':'c'*64,'parent_id':'folder','name':'canary.txt','sha256':sha,'size':len(self.body)}
        path=b'work-materials/canary.txt'
        manifest=canonical_json_bytes({'schema_version':'drive-exchange-manifest-v1','project_id':'synthetic','route':'standard','files':[{'path':path.decode(),'byte_size':len(self.body),'sha256':sha}]})
        self.frame=b'DXSTAGE\x00\x01'+struct.pack('>Q',len(manifest))+manifest+struct.pack('>I',len(path))+path+struct.pack('>Q',len(self.body))+self.body
        self.request={'schema_version':'drive-exchange-local-request-v1','operation_id':'op_'+'d'*32,'project_id':'synthetic','project_identity':project_identity_for_root(self.root),'route_name':'standard','mode':'submit','manifest_sha256':hashlib.sha256(manifest).hexdigest(),'frame_sha256':hashlib.sha256(self.frame).hexdigest()}
        self.set_operation()
    def set_operation(self):
        r=self.request;self.request['operation_id']='op_'+hashlib.sha256(canonical_json_bytes([r['project_id'],r['project_identity'],r['route_name'],self.desc['key']])).hexdigest()[:32]
    def call(self,action):
        return self.hub.exchange(canonical_json_bytes({'schema_version':'drive-exchange-material-recovery-v1','action':action,'request':self.request,'descriptor':self.desc}),self.frame)
    def test_create_response_loss_restart_exact_identity_readback(self):
        first=self.call('lookup');self.assertTrue(first['safe_to_create'])
        self.provider.drop=True;self.assertEqual(self.call('upload')['status'],'unknown')
        self.hub=LocalHub(store=HubStore(self.root/'hub.sqlite'),connector=self.provider)
        found=self.call('lookup');self.assertEqual(found['file_id'],first['file_id'])
        read=self.call('readback');self.assertEqual(base64.b64decode(read['content_base64']),self.body)
        self.assertEqual((self.provider.reserved,self.provider.creates),(1,1))
        self.assertEqual(self.call('upload')['file_id'],found['file_id'])
        self.assertEqual(self.provider.creates,1)
    def test_permission_binding_and_frozen_hash_rejected_before_cloud(self):
        for key,value in [('parent_id','other'),('sha256','0'*64),('name','else.txt')]:
            old=self.desc[key];self.desc[key]=value
            with self.assertRaises(HubError):self.call('lookup')
            self.desc[key]=old
        self.assertEqual(self.provider.reserved,0)
        self.request['project_identity']='wrong'
        with self.assertRaises(HubError):self.call('lookup')
    def test_same_operation_different_descriptor_and_old_operation_rejected(self):
        self.call('lookup');self.desc['batch_id']='f'*64
        with self.assertRaises(HubError):self.call('lookup')
        self.desc['key']='e'*64+':0';self.set_operation()
        with self.store._connect() as db:db.execute("INSERT INTO operations VALUES (?, ?, ?, ?, 'AMBIGUOUS', 1, NULL, NULL, 'now', NULL)",(self.request['operation_id'],'old','synthetic','standard'))
        with self.assertRaises(HubError):self.call('lookup')
        self.assertEqual(self.provider.reserved,1)
    def test_remote_mismatch_never_found_or_recreated(self):
        self.call('lookup');self.call('upload');remote=next(iter(self.provider.objects))
        self.provider.objects[remote][0]['name']='tampered'
        self.assertEqual(self.call('lookup')['status'],'unknown')
        self.assertEqual(self.call('upload')['status'],'unknown')
        self.assertEqual(self.provider.creates,1)
    def test_disabled_route_recovery_denied(self):
        self.call('lookup');self.store.disable_route('synthetic','standard')
        with self.assertRaises(HubError):self.call('upload')
        self.assertEqual(self.provider.creates,0)

    def test_recovery_claim_blocks_legacy_path_before_dispatch(self):
        self.call('lookup')
        with self.assertRaisesRegex(HubError,'OPERATION_ID_CONFLICT'):
            self.hub.exchange(canonical_json_bytes(self.request),self.frame)
        self.assertEqual(self.provider.creates,0)

    def test_reservation_network_error_is_bounded_hub_error(self):
        def fail(identity):raise TimeoutError('synthetic')
        self.provider.reserve_material_id=fail
        with self.assertRaisesRegex(HubError,'MATERIAL_RESERVATION_UNKNOWN'):
            self.call('lookup')
        self.assertEqual(self.provider.creates,0)

if __name__=='__main__':unittest.main()
