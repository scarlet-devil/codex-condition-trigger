from __future__ import annotations

import base64
import hashlib
import json
import mimetypes
import os
import re
import stat
import threading
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request
import uuid
import webbrowser
from dataclasses import dataclass
from http.client import RemoteDisconnected
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Callable

from . import (
    ConnectorAmbiguousError,
    ConnectorDefinitiveError,
    HubError,
    canonical_json_bytes,
)
from .ports import CredentialStore
from .windows_credentials import DEFAULT_CREDENTIAL_TARGET, WindowsCredentialStore


DRIVE_FILE_SCOPE = "https://www.googleapis.com/auth/drive.file"
_AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth"
_TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token"
_DRIVE_API = "https://www.googleapis.com/drive/v3"
_DRIVE_UPLOAD = "https://www.googleapis.com/upload/drive/v3/files"
_SHEETS_API = "https://sheets.googleapis.com/v4/spreadsheets"
_FOLDER_MIME_TYPE = "application/vnd.google-apps.folder"
_CLIENT_CONFIG_NAME = "oauth-client.local.json"
_CLIENT_CONFIG_SCHEMA = "drive-exchange-google-oauth-client-v2"
_CREDENTIAL_SCHEMA = "drive-exchange-google-credential-v1"
_PROVIDER_ERROR_CODE_MAX_UTF8 = 256
_PROVIDER_ERROR_MESSAGE_MAX_UTF8 = 2048
_TOKEN_PROVIDER_ERRORS = frozenset(
    {
        "invalid_request",
        "invalid_client",
        "invalid_grant",
        "unauthorized_client",
        "unsupported_grant_type",
        "invalid_scope",
    }
)
_TOKEN_PUBLIC_FIELDS = frozenset(
    {"client_id", "code", "code_verifier", "grant_type", "redirect_uri"}
)
_TOKEN_FIELD_NAME = re.compile(
    r"(?<![A-Za-z0-9_])(client_id|code_verifier|grant_type|redirect_uri|code)"
    r"(?![A-Za-z0-9_])",
    re.IGNORECASE,
)


class OAuthTokenExchangeError(HubError):
    def __init__(self, diagnostic: dict[str, object]) -> None:
        self.oauth_diagnostic = dict(diagnostic)
        super().__init__("OAUTH_TOKEN_EXCHANGE_FAILED")


@dataclass(frozen=True)
class _HttpResponse:
    status: int
    body: bytes
    headers: dict[str, str]


def _base64url(value: bytes) -> str:
    return base64.urlsafe_b64encode(value).rstrip(b"=").decode("ascii")


def _json_no_duplicates(raw: bytes, error_code: str) -> dict:
    def object_pairs(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("duplicate key")
            result[key] = value
        return result

    try:
        value = json.loads(
            raw.decode("utf-8", errors="strict"), object_pairs_hook=object_pairs
        )
    except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as error:
        raise HubError(error_code) from error
    if not isinstance(value, dict):
        raise HubError(error_code)
    return value


def _default_http_request(
    *, method: str, url: str, headers: dict[str, str], body: bytes | None = None,
    max_response_bytes: int | None = None,
) -> _HttpResponse:
    def bounded_read(stream):
        if max_response_bytes is None:
            return stream.read()
        data = stream.read(max_response_bytes + 1)
        if len(data) > max_response_bytes:
            raise HubError('MATERIAL_READBACK_LIMIT')
        return data
    request = urllib.request.Request(url=url, data=body, headers=headers, method=method)
    parsed = urllib.parse.urlsplit(url)
    pure_read = method == "GET" and body is None and parsed.scheme == "https" and (
        parsed.netloc == "www.googleapis.com" and (
            parsed.path in {"/drive/v3/about", "/drive/v3/files"}
            or re.fullmatch(r"/drive/v3/files/(?!generateIds$)[A-Za-z0-9_-]+", parsed.path)
        )
        or parsed.netloc == "sheets.googleapis.com"
        and re.fullmatch(r"/v4/spreadsheets/[A-Za-z0-9_-]+", parsed.path)
    )
    attempts = 3 if pure_read else 1
    for attempt in range(attempts):
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                return _HttpResponse(
                    status=response.status,
                    body=bounded_read(response),
                    headers=dict(response.headers.items()),
                )
        except urllib.error.HTTPError as error:
            return _HttpResponse(
                status=error.code,
                body=bounded_read(error),
                headers=dict(error.headers.items()) if error.headers else {},
            )
        except RemoteDisconnected:
            if attempt + 1 == attempts:
                raise
            time.sleep(0.25 * (attempt + 1))
    raise AssertionError("unreachable HTTP attempt state")


class _CallbackHandler(BaseHTTPRequestHandler):
    server_version = "DriveExchangeCallback/1"

    def do_GET(self) -> None:  # noqa: N802
        parsed = urllib.parse.urlparse(self.path)
        try:
            values = urllib.parse.parse_qs(
                parsed.query, keep_blank_values=True, strict_parsing=True
            )
        except ValueError:
            values = {}
        if parsed.path != "/" or any(len(items) != 1 for items in values.values()):
            result = {"_invalid": "true"}
            status = 400
        else:
            result = {key: items[0] for key, items in values.items()}
            status = 200
        self.server.callback_result = result
        self.send_response(status)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(b"Drive Exchange authorization response received.")
        self.server.callback_event.set()

    def log_message(self, _format: str, *_args) -> None:
        return


class _LoopbackCallbackServer:
    def __init__(self) -> None:
        self._server = ThreadingHTTPServer(("127.0.0.1", 0), _CallbackHandler)
        self._server.callback_event = threading.Event()
        self._server.callback_result = None
        self._thread: threading.Thread | None = None
        self.redirect_uri = f"http://127.0.0.1:{self._server.server_port}/"

    def __enter__(self):
        self._thread = threading.Thread(
            target=self._server.serve_forever,
            name="drive-exchange-oauth-callback",
            daemon=True,
        )
        self._thread.start()
        return self

    def __exit__(self, *_args) -> None:
        self._server.shutdown()
        self._server.server_close()
        if self._thread is not None:
            self._thread.join(timeout=5)

    def receive(self, timeout_seconds: int) -> dict[str, str]:
        if not self._server.callback_event.wait(timeout_seconds):
            raise HubError("OAUTH_CALLBACK_INVALID")
        result = self._server.callback_result
        if not isinstance(result, dict):
            raise HubError("OAUTH_CALLBACK_INVALID")
        return result


class GoogleDriveAdapter:
    max_items_per_operation = 1

    def __init__(
        self,
        *,
        client_id: str,
        client_secret: str,
        credential_store: CredentialStore,
        browser_open: Callable[[str], object] = webbrowser.open,
        callback_server_factory: Callable[[], object] = _LoopbackCallbackServer,
        http_request: Callable[..., object] = _default_http_request,
        entropy: Callable[[int], bytes] = os.urandom,
        clock: Callable[[], float] = time.time,
    ) -> None:
        if (
            not isinstance(client_id, str)
            or not client_id.endswith(".apps.googleusercontent.com")
            or len(client_id) > 512
            or not isinstance(client_secret, str)
            or not client_secret
            or len(client_secret) > 2048
        ):
            raise HubError("OAUTH_CLIENT_CONFIG_INVALID")
        self._client_id = client_id
        self._client_secret = client_secret
        self._credential_store = credential_store
        self._browser_open = browser_open
        self._callback_server_factory = callback_server_factory
        self._http_request = http_request
        self._entropy = entropy
        self._clock = clock

    def has_credential(self) -> bool:
        return self._credential_store.read(DEFAULT_CREDENTIAL_TARGET) is not None

    def authorize_and_select_folder(self) -> dict:
        verifier = _base64url(self._entropy(64))
        state_value = _base64url(self._entropy(32))
        challenge = _base64url(hashlib.sha256(verifier.encode("ascii")).digest())
        with self._callback_server_factory() as callback:
            query = urllib.parse.urlencode(
                {
                    "access_type": "offline",
                    "allow_folder_selection": "true",
                    "client_id": self._client_id,
                    "code_challenge": challenge,
                    "code_challenge_method": "S256",
                    "prompt": "consent",
                    "redirect_uri": callback.redirect_uri,
                    "response_type": "code",
                    "scope": DRIVE_FILE_SCOPE,
                    "state": state_value,
                    "trigger_onepick": "true",
                }
            )
            opened = self._browser_open(_AUTH_ENDPOINT + "?" + query)
            if opened is False:
                raise HubError("OAUTH_BROWSER_FAILED")
            response = callback.receive(300)
        if (
            not isinstance(response, dict)
            or not {"state", "code", "scope", "picked_file_ids"}.issubset(response)
            or "error" in response
            or not all(
                isinstance(key, str) and isinstance(value, str)
                for key, value in response.items()
            )
            or response.get("state") != state_value
            or response.get("scope") != DRIVE_FILE_SCOPE
            or not isinstance(response.get("code"), str)
            or not response["code"]
            or not isinstance(response.get("picked_file_ids"), str)
            or not response["picked_file_ids"]
            or "," in response["picked_file_ids"]
        ):
            raise HubError("OAUTH_CALLBACK_INVALID")
        token_body = urllib.parse.urlencode(
            {
                "client_id": self._client_id,
                "client_secret": self._client_secret,
                "code": response["code"],
                "code_verifier": verifier,
                "grant_type": "authorization_code",
                "redirect_uri": callback.redirect_uri,
            }
        ).encode("ascii")
        token_response = self._request_json(
            method="POST",
            url=_TOKEN_ENDPOINT,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            body=token_body,
            error_code="OAUTH_TOKEN_EXCHANGE_FAILED",
        )
        credential = self._credential_from_token_response(token_response)
        previous_credential = self._credential_store.read(DEFAULT_CREDENTIAL_TARGET)
        self._credential_store.write(
            DEFAULT_CREDENTIAL_TARGET, canonical_json_bytes(credential)
        )
        folder_id = response["picked_file_ids"]
        try:
            return self._verification(folder_id, credential)
        except Exception:
            if previous_credential is None:
                self._credential_store.delete(DEFAULT_CREDENTIAL_TARGET)
            else:
                self._credential_store.write(
                    DEFAULT_CREDENTIAL_TARGET, previous_credential
                )
            raise

    def verify_folder(self, folder_id: str) -> dict:
        return self._verification(folder_id, self._load_credential())

    def verify_existing_folder(
        self,
        folder_id: str,
        *,
        expected_parent_id: str,
        expected_drive_identity: str,
    ) -> dict:
        for remote_id in (folder_id, expected_parent_id):
            if (
                not isinstance(remote_id, str)
                or re.fullmatch(r"[A-Za-z0-9_-]{1,512}", remote_id) is None
            ):
                raise HubError("EXISTING_FOLDER_INPUT_INVALID")
        if (
            not isinstance(expected_drive_identity, str)
            or len(expected_drive_identity) > 512
            or re.fullmatch(r"google-drive:[A-Za-z0-9_-]+", expected_drive_identity)
            is None
        ):
            raise HubError("EXISTING_FOLDER_INPUT_INVALID")
        try:
            credential = self._load_credential()
            identity = self._drive_identity(credential)
            if identity != expected_drive_identity:
                raise HubError("EXISTING_FOLDER_UNVERIFIED")
            metadata = self._authorized_json(
                credential,
                _DRIVE_API
                + "/files/"
                + urllib.parse.quote(folder_id, safe="")
                + "?fields=id,mimeType,trashed,parents,"
                "capabilities(canAddChildren,canListChildren)&supportsAllDrives=true",
                "EXISTING_FOLDER_UNVERIFIED",
            )
            capabilities = metadata.get("capabilities")
            if (
                set(metadata) != {"id", "mimeType", "trashed", "parents", "capabilities"}
                or metadata.get("id") != folder_id
                or metadata.get("mimeType") != _FOLDER_MIME_TYPE
                or metadata.get("trashed") is not False
                or metadata.get("parents") != [expected_parent_id]
                or not isinstance(capabilities, dict)
                or set(capabilities) != {"canAddChildren", "canListChildren"}
                or capabilities["canAddChildren"] is not True
                or capabilities["canListChildren"] is not True
            ):
                raise HubError("EXISTING_FOLDER_UNVERIFIED")
        except Exception:
            raise HubError("EXISTING_FOLDER_UNVERIFIED") from None
        return {
            "verified": True,
            "folder_id": folder_id,
            "parent_folder_id": expected_parent_id,
            "drive_identity": identity,
            "can_add_children": True,
            "can_list_children": True,
        }

    def reserve_material_id(self, expected_drive_identity: str) -> str:
        credential = self._recovery_credential(expected_drive_identity)
        value = self._authorized_json(credential,
            _DRIVE_API + '/files/generateIds?count=1&space=drive&type=files', 'MATERIAL_RESERVATION_INVALID')
        ids = value.get('ids')
        if not isinstance(ids, list) or len(ids) != 1 or not isinstance(ids[0], str):
            raise HubError('MATERIAL_RESERVATION_INVALID')
        return ids[0]

    def material_action(self, action, expected_drive_identity, remote_id, descriptor, body):
        """Reserved-ID byte upload; only the Hub's validated recovery entry calls it."""
        credential = self._recovery_credential(expected_drive_identity)
        headers = {'Authorization': 'Bearer ' + credential['access_token']}
        url = _DRIVE_API + '/files/' + urllib.parse.quote(remote_id, safe='')
        fields = '?fields=id,name,parents,trashed,appProperties'
        if action == 'upload':
            # Always query this ID before create, including after response loss.
            before = self._http_request(method='GET', url=url + fields, headers=headers, body=None)
            if before.status == 404:
                boundary = 'condition-' + uuid.uuid4().hex
                metadata = canonical_json_bytes(dict(id=remote_id, name=descriptor['name'],
                    parents=[descriptor['parent_id']], appProperties={
                        'condition_key': descriptor['key'], 'source_sha256': descriptor['sha256']}))
                multipart = (f'--{boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n'.encode()
                    + metadata + f'\r\n--{boundary}\r\nContent-Type: application/octet-stream\r\n\r\n'.encode()
                    + body + f'\r\n--{boundary}--\r\n'.encode())
                created = self._http_request(method='POST', url=_DRIVE_UPLOAD+'?uploadType=multipart&fields=id',
                    headers={**headers,'Content-Type':'multipart/related; boundary='+boundary}, body=multipart)
                if created.status not in (200,201,409):
                    raise HubError('MATERIAL_CREATE_UNKNOWN')
            elif before.status != 200:
                raise HubError('MATERIAL_LOOKUP_UNKNOWN')
        response = self._http_request(method='GET', url=url+fields, headers=headers, body=None)
        if response.status == 404:
            return None
        if response.status != 200:
            raise HubError('MATERIAL_LOOKUP_UNKNOWN')
        result = self._response_json(response,'MATERIAL_LOOKUP_INVALID')
        if action == 'readback':
            response = self._http_request(method='GET', url=url+'?alt=media', headers=headers, body=None,
                                          max_response_bytes=descriptor['size'])
            if response.status != 200:
                raise HubError('MATERIAL_READBACK_UNKNOWN')
            if len(response.body)>descriptor['size']:
                raise HubError('MATERIAL_READBACK_LIMIT')
            result['content_base64'] = base64.b64encode(response.body).decode('ascii')
        return result

    def upload(
        self,
        *,
        folder_id: str,
        expected_drive_identity: str,
        source_path: str,
        body: bytes,
        operation_id: str,
    ) -> dict:
        credential = self._load_credential()
        identity = self._drive_identity(credential)
        if identity != expected_drive_identity:
            raise ConnectorDefinitiveError(
                {
                    "code": "driveIdentityMismatch",
                    "message": "active Drive identity does not match route binding",
                }
            )
        boundary = "drive-exchange-" + uuid.uuid4().hex
        metadata = canonical_json_bytes(
            {
                "appProperties": {
                    "drive_exchange_operation_id": operation_id,
                    "source_sha256": hashlib.sha256(body).hexdigest(),
                },
                "name": Path(source_path).name,
                "parents": [folder_id],
            }
        )
        mime_type = mimetypes.guess_type(source_path)[0] or "application/octet-stream"
        multipart = (
            f"--{boundary}\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n".encode(
                "ascii"
            )
            + metadata
            + f"\r\n--{boundary}\r\nContent-Type: {mime_type}\r\n\r\n".encode(
                "ascii"
            )
            + body
            + f"\r\n--{boundary}--\r\n".encode("ascii")
        )
        try:
            response = self._http_request(
                method="POST",
                url=_DRIVE_UPLOAD
                + "?uploadType=multipart&fields=id,parents,size,appProperties",
                headers={
                    "Authorization": "Bearer " + credential["access_token"],
                    "Content-Type": "multipart/related; boundary=" + boundary,
                },
                body=multipart,
            )
        except Exception as error:
            raise ConnectorAmbiguousError(
                {"code": "createOutcomeUnknown", "message": "Drive create outcome unknown"}
            ) from error
        if not hasattr(response, "status") or not hasattr(response, "body"):
            raise ConnectorAmbiguousError(
                {"code": "createOutcomeUnknown", "message": "Drive create outcome unknown"}
            )
        if response.status >= 500:
            raise ConnectorAmbiguousError(self._provider_error(response))
        if response.status >= 400:
            raise ConnectorDefinitiveError(self._provider_error(response))
        try:
            created = self._response_json(response, "DRIVE_CREATE_RESPONSE_INVALID")
            remote_file_id = created["id"]
            parents = created["parents"]
            size = created["size"]
            app_properties = created["appProperties"]
            if (
                not isinstance(remote_file_id, str)
                or not remote_file_id
                or parents != [folder_id]
                or not isinstance(size, str)
                or size != str(len(body))
                or app_properties
                != {
                    "drive_exchange_operation_id": operation_id,
                    "source_sha256": hashlib.sha256(body).hexdigest(),
                }
            ):
                raise ValueError("mapping")
            revisions = self._authorized_json(
                credential,
                _DRIVE_API
                + "/files/"
                + urllib.parse.quote(remote_file_id, safe="")
                + "/revisions?fields=revisions(id)",
                "DRIVE_REVISION_INVALID",
            )
            revision_items = revisions.get("revisions")
            if not isinstance(revision_items, list) or not revision_items:
                raise ValueError("revision")
            revision = revision_items[-1].get("id")
            if not isinstance(revision, str) or not revision:
                raise ValueError("revision")
            raw_response = self._http_request(
                method="GET",
                url=_DRIVE_API
                + "/files/"
                + urllib.parse.quote(remote_file_id, safe="")
                + "?alt=media",
                headers={"Authorization": "Bearer " + credential["access_token"]},
                body=None,
            )
            if raw_response.status != 200 or raw_response.body != body:
                raise ConnectorAmbiguousError(
                    {
                        "code": "rawReadbackMismatch",
                        "message": "remote raw bytes do not match submitted bytes",
                    }
                )
        except ConnectorAmbiguousError:
            raise
        except Exception as error:
            raise ConnectorAmbiguousError(
                {
                    "code": "remoteVerificationIncomplete",
                    "message": "created file could not be verified exactly",
                }
            ) from error
        return {
            "remote_file_id": remote_file_id,
            "revision": revision,
            "byte_size": len(body),
            "sha256": hashlib.sha256(body).hexdigest(),
        }

    @staticmethod
    def _topology_object(value: object) -> dict:
        keys = {"id", "name", "mimeType", "parents", "trashed", "appProperties"}
        if not isinstance(value, dict) or set(value) != keys:
            raise ValueError("topology object shape")
        if (
            not isinstance(value["id"], str)
            or not value["id"]
            or not isinstance(value["name"], str)
            or not value["name"]
            or value["mimeType"] not in {_FOLDER_MIME_TYPE, "application/vnd.google-apps.spreadsheet"}
            or not isinstance(value["parents"], list)
            or len(value["parents"]) != 1
            or not isinstance(value["parents"][0], str)
            or type(value["trashed"]) is not bool
            or not isinstance(value["appProperties"], dict)
            or not all(isinstance(key, str) and isinstance(item, str) for key, item in value["appProperties"].items())
        ):
            raise ValueError("topology object values")
        return {
            "id": value["id"],
            "name": value["name"],
            "mime_type": value["mimeType"],
            "parents": list(value["parents"]),
            "trashed": value["trashed"],
            "app_properties": dict(value["appProperties"]),
        }

    def _topology_mutation_json(
        self, *, method: str, url: str, body: bytes, error_message: str
    ) -> dict:
        credential = self._load_credential()
        try:
            response = self._http_request(
                method=method,
                url=url,
                headers={
                    "Authorization": "Bearer " + credential["access_token"],
                    "Content-Type": "application/json; charset=UTF-8",
                },
                body=body,
            )
        except Exception as error:
            raise ConnectorAmbiguousError(
                {"code": "mutationOutcomeUnknown", "message": error_message}
            ) from error
        if not hasattr(response, "status") or not hasattr(response, "body"):
            raise ConnectorAmbiguousError(
                {"code": "mutationOutcomeUnknown", "message": error_message}
            )
        if response.status >= 500:
            raise ConnectorAmbiguousError(self._provider_error(response))
        if response.status >= 400:
            raise ConnectorDefinitiveError(self._provider_error(response))
        try:
            return self._response_json(response, "DRIVE_TOPOLOGY_RESPONSE_INVALID")
        except HubError as error:
            raise ConnectorAmbiguousError(
                {"code": "mutationVerificationIncomplete", "message": error_message}
            ) from error

    def select_parent_folder(self) -> dict:
        selected = self.authorize_and_select_folder()
        credential = self._load_credential()
        folder_id = selected["folder_id"]
        metadata = self._authorized_json(
            credential,
            _DRIVE_API + "/files/" + urllib.parse.quote(folder_id, safe="")
            + "?fields=id,mimeType,trashed,driveId,capabilities(canAddChildren,canListChildren)",
            "BOOTSTRAP_PARENT_INVALID",
        )
        required = {"id", "mimeType", "trashed", "capabilities"}
        if frozenset(metadata) not in {frozenset(required), frozenset(required | {"driveId"})}:
            raise HubError("BOOTSTRAP_PARENT_INVALID")
        capabilities = metadata["capabilities"]
        if (
            metadata["id"] != folder_id
            or metadata["mimeType"] != _FOLDER_MIME_TYPE
            or metadata["trashed"] is not False
            or not isinstance(capabilities, dict)
            or set(capabilities) != {"canAddChildren", "canListChildren"}
            or capabilities["canAddChildren"] is not True
            or capabilities["canListChildren"] is not True
        ):
            raise HubError("BOOTSTRAP_PARENT_INVALID")
        result = {
            "folder_id": folder_id,
            "drive_identity": selected["drive_identity"],
            "mime_type": metadata["mimeType"],
            "trashed": metadata["trashed"],
            "capabilities": dict(capabilities),
        }
        if "driveId" in metadata:
            if not isinstance(metadata["driveId"], str) or not metadata["driveId"]:
                raise HubError("BOOTSTRAP_PARENT_INVALID")
            result["driveId"] = metadata["driveId"]
        return result

    def _list_topology_objects(
        self,
        *,
        parent_id: str | None,
        clauses: list[str],
        require_untrashed: bool,
        credential: dict | None = None,
        include_all_drives: bool = False,
    ) -> list[dict]:
        if credential is None:
            credential = self._load_credential()
        page_token: str | None = None
        result: list[dict] = []
        while True:
            query = [*clauses]
            if require_untrashed:
                query.insert(0, "trashed = false")
            if parent_id is not None:
                query.insert(0, f"'{parent_id}' in parents")
            parameters = {
                "q": " and ".join(query),
                "pageSize": "1000",
                "fields": "nextPageToken,files(id,name,mimeType,parents,trashed,appProperties)",
            }
            if include_all_drives:
                parameters["includeItemsFromAllDrives"] = "true"
                parameters["supportsAllDrives"] = "true"
            if page_token is not None:
                parameters["pageToken"] = page_token
            payload = self._authorized_json(
                credential,
                _DRIVE_API + "/files?" + urllib.parse.urlencode(parameters),
                "BOOTSTRAP_LOOKUP_INVALID",
            )
            if set(payload) not in ({"files"}, {"files", "nextPageToken"}) or not isinstance(payload["files"], list):
                raise HubError("BOOTSTRAP_LOOKUP_INVALID")
            try:
                result.extend(self._topology_object(item) for item in payload["files"])
            except ValueError as error:
                raise HubError("BOOTSTRAP_LOOKUP_INVALID") from error
            page_token = payload.get("nextPageToken")
            if page_token is None:
                return result
            if not isinstance(page_token, str) or not page_token:
                raise HubError("BOOTSTRAP_LOOKUP_INVALID")

    def list_project_roots(
        self, *, parent_id: str, project_id: str, project_identity: str
    ) -> list[dict]:
        escaped = project_id.replace("'", "\\'")
        escaped_identity = project_identity.replace("'", "\\'")
        return self._list_topology_objects(
            parent_id=parent_id,
            clauses=[
                f"appProperties has {{ key='project_id' and value='{escaped}' }}",
                f"appProperties has {{ key='project_identity' and value='{escaped_identity}' }}",
                "appProperties has { key='role' and value='project_root' }",
            ],
            require_untrashed=True,
        )

    def list_operation_objects(
        self, *, operation_id: str, expected_drive_identity: str
    ) -> list[dict]:
        credential = self._recovery_credential(expected_drive_identity)
        escaped = operation_id.replace("'", "\\'")
        return self._list_topology_objects(
            parent_id=None,
            clauses=[f"appProperties has {{ key='operation_id' and value='{escaped}' }}"],
            require_untrashed=False,
            credential=credential,
            include_all_drives=True,
        )

    def reserve_folder_ids(self, count: int) -> list[str]:
        if type(count) is not int or count < 1 or count > 100:
            raise HubError("BOOTSTRAP_REQUEST_INVALID")
        credential = self._load_credential()
        payload = self._authorized_json(
            credential,
            _DRIVE_API + "/files/generateIds?" + urllib.parse.urlencode(
                {"count": str(count), "space": "drive", "type": "files"}
            ),
            "BOOTSTRAP_ID_RESERVATION_INVALID",
        )
        ids = payload.get("ids")
        if (
            set(payload) != {"ids", "space", "kind"}
            or payload.get("space") != "drive"
            or payload.get("kind") != "drive#generatedIds"
            or not isinstance(ids, list)
            or len(ids) != count
            or any(not isinstance(item, str) or not item for item in ids)
            or len(set(ids)) != count
        ):
            raise HubError("BOOTSTRAP_ID_RESERVATION_INVALID")
        return ids

    def create_folder(
        self,
        *,
        remote_id: str,
        parent_id: str,
        name: str,
        app_properties: dict[str, str],
    ) -> dict:
        body = canonical_json_bytes({
            "id": remote_id, "name": name, "parents": [parent_id],
            "mimeType": _FOLDER_MIME_TYPE, "appProperties": app_properties,
        })
        value = self._topology_mutation_json(
            method="POST",
            url=_DRIVE_API + "/files?fields=id,name,mimeType,parents,trashed,appProperties",
            body=body,
            error_message="folder create outcome unknown",
        )
        try:
            return self._topology_object(value)
        except ValueError as error:
            raise ConnectorAmbiguousError(
                {"code": "mutationVerificationIncomplete", "message": "folder create could not be verified"}
            ) from error

    def create_catalog(
        self,
        *,
        parent_id: str,
        name: str,
        app_properties: dict[str, str],
    ) -> dict:
        body = canonical_json_bytes({
            "name": name, "parents": [parent_id],
            "mimeType": "application/vnd.google-apps.spreadsheet",
            "appProperties": app_properties,
        })
        value = self._topology_mutation_json(
            method="POST",
            url=_DRIVE_API + "/files?fields=id,name,mimeType,parents,trashed,appProperties",
            body=body,
            error_message="catalog create outcome unknown",
        )
        try:
            return self._topology_object(value)
        except ValueError as error:
            raise ConnectorAmbiguousError(
                {"code": "mutationVerificationIncomplete", "message": "catalog create could not be verified"}
            ) from error

    def apply_catalog_template(self, *, remote_id: str, batch_update: dict) -> dict:
        body = canonical_json_bytes(batch_update)
        value = self._topology_mutation_json(
            method="POST",
            url=_SHEETS_API + "/" + urllib.parse.quote(remote_id, safe="") + ":batchUpdate",
            body=body,
            error_message="catalog template outcome unknown",
        )
        if not isinstance(value.get("spreadsheetId"), str) or value["spreadsheetId"] != remote_id or not isinstance(value.get("replies"), list):
            raise ConnectorAmbiguousError(
                {"code": "mutationVerificationIncomplete", "message": "catalog template could not be verified"}
            )
        digest = hashlib.sha256(body).hexdigest()
        return {"remote_id": remote_id, "template_sha256": digest, "applied": True}

    def _read_catalog_payload(self, remote_id: str) -> dict:
        credential = self._load_credential()
        payload = self._authorized_json(
            credential,
            _SHEETS_API + "/" + urllib.parse.quote(remote_id, safe="")
            + "?includeGridData=true&fields=spreadsheetId,sheets(properties(sheetId,title),data(rowData(values(userEnteredValue))))",
            "CATALOG_READBACK_INVALID",
        )
        if set(payload) != {"spreadsheetId", "sheets"} or payload.get("spreadsheetId") != remote_id or not isinstance(payload.get("sheets"), list):
            raise HubError("CATALOG_READBACK_INVALID")
        return payload

    @staticmethod
    def _catalog_expectation(expected_batch_update: dict) -> tuple[str, dict[int, str], dict[int, list]]:
        try:
            template_body = canonical_json_bytes(expected_batch_update)
            template = json.loads(template_body)
        except (TypeError, ValueError) as error:
            raise HubError("CATALOG_READBACK_INVALID") from error
        digest = hashlib.sha256(template_body).hexdigest()
        try:
            expected_titles: dict[int, str] = {0: "START_HERE"}
            expected_rows: dict[int, list] = {}
            for request in template["requests"]:
                if "updateSheetProperties" in request:
                    properties = request["updateSheetProperties"]["properties"]
                    expected_titles[properties["sheetId"]] = properties["title"]
                elif "addSheet" in request:
                    properties = request["addSheet"]["properties"]
                    expected_titles[properties["sheetId"]] = properties["title"]
                elif "updateCells" in request:
                    update = request["updateCells"]
                    expected_rows[update["start"]["sheetId"]] = update["rows"]
            if set(expected_titles) != {0, 1} or set(expected_rows) != {0, 1}:
                raise ValueError("template topology")
        except (KeyError, TypeError, ValueError) as error:
            raise HubError("CATALOG_READBACK_INVALID") from error
        return digest, expected_titles, expected_rows

    @staticmethod
    def _catalog_actual(payload: dict) -> dict[int, tuple[str, list]]:
        try:
            actual: dict[int, tuple[str, list]] = {}
            for sheet in payload["sheets"]:
                if not isinstance(sheet, dict) or set(sheet) not in (
                    {"properties"}, {"properties", "data"}
                ):
                    raise ValueError("sheet shape")
                properties = sheet["properties"]
                if (
                    not isinstance(properties, dict)
                    or set(properties) != {"sheetId", "title"}
                    or type(properties["sheetId"]) is not int
                    or not isinstance(properties["title"], str)
                    or not properties["title"]
                    or properties["sheetId"] in actual
                ):
                    raise ValueError("sheet properties")
                data = sheet.get("data", [])
                if not isinstance(data, list) or len(data) > 1:
                    raise ValueError("sheet data")
                if not data:
                    rows: list = []
                else:
                    if not isinstance(data[0], dict) or set(data[0]) not in (
                        set(), {"rowData"}
                    ):
                        raise ValueError("sheet grid")
                    rows = data[0].get("rowData", [])
                    if not isinstance(rows, list):
                        raise ValueError("sheet rows")
                actual[properties["sheetId"]] = (properties["title"], rows)
            return actual
        except (KeyError, TypeError, ValueError) as error:
            raise HubError("CATALOG_READBACK_INVALID") from error

    def inspect_catalog(self, remote_id: str, expected_batch_update: dict) -> dict:
        payload = self._read_catalog_payload(remote_id)
        digest, expected_titles, expected_rows = self._catalog_expectation(
            expected_batch_update
        )
        actual = self._catalog_actual(payload)
        if set(actual) == {0, 1} and all(
            actual[sheet_id] == (expected_titles[sheet_id], expected_rows[sheet_id])
            for sheet_id in (0, 1)
        ):
            return {
                "remote_id": remote_id,
                "state": "EXACT_TEMPLATE",
                "template_sha256": digest,
            }
        if set(actual) == {0} and actual[0][1] == []:
            return {"remote_id": remote_id, "state": "PRISTINE"}
        raise HubError("CATALOG_READBACK_INVALID")

    def read_catalog(self, remote_id: str, expected_batch_update: dict) -> dict:
        inspected = self.inspect_catalog(remote_id, expected_batch_update)
        if inspected.get("state") != "EXACT_TEMPLATE":
            raise HubError("CATALOG_READBACK_INVALID")
        digest = inspected.get("template_sha256")
        if not isinstance(digest, str):
            raise HubError("CATALOG_READBACK_INVALID")
        return {"remote_id": remote_id, "template_sha256": digest}

    def get_object(self, remote_id: str, *, expected_drive_identity: str) -> dict:
        credential = self._recovery_credential(expected_drive_identity)
        try:
            response = self._http_request(
                method="GET",
                url=_DRIVE_API + "/files/" + urllib.parse.quote(remote_id, safe="")
                + "?fields=id,name,mimeType,parents,trashed,appProperties&supportsAllDrives=true",
                headers={"Authorization": "Bearer " + credential["access_token"]},
                body=None,
            )
        except Exception as error:
            raise ConnectorAmbiguousError(
                {"code": "readOutcomeUnresolved", "message": "object read outcome unresolved"}
            ) from error
        status = getattr(response, "status", None)
        if status == 404:
            raise ConnectorDefinitiveError(
                {"code": "notFound", "message": "object not found"}
            )
        if type(status) is not int or status < 200 or status >= 300:
            raise ConnectorAmbiguousError(
                {"code": "readOutcomeUnresolved", "message": "object read outcome unresolved"}
            )
        try:
            value = self._response_json(response, "BOOTSTRAP_OBJECT_READBACK_INVALID")
        except HubError as error:
            raise ConnectorAmbiguousError(
                {"code": "readOutcomeUnresolved", "message": "object read outcome unresolved"}
            ) from error
        try:
            return self._topology_object(value)
        except ValueError as error:
            raise ConnectorAmbiguousError(
                {"code": "readOutcomeUnresolved", "message": "object read outcome unresolved"}
            ) from error

    def rename_object(self, *, remote_id: str, name: str) -> dict:
        value = self._topology_mutation_json(
            method="PATCH",
            url=_DRIVE_API + "/files/" + urllib.parse.quote(remote_id, safe="")
            + "?fields=id,name,mimeType,parents,trashed,appProperties",
            body=canonical_json_bytes({"name": name}),
            error_message="rename outcome unknown",
        )
        try:
            return self._topology_object(value)
        except ValueError as error:
            raise ConnectorAmbiguousError(
                {"code": "mutationVerificationIncomplete", "message": "rename could not be verified"}
            ) from error

    def _verification(self, folder_id: str, credential: dict) -> dict:
        if not isinstance(folder_id, str) or not folder_id or len(folder_id) > 512:
            raise HubError("ROUTE_BINDING_UNVERIFIED")
        identity = self._drive_identity(credential)
        metadata = self._authorized_json(
            credential,
            _DRIVE_API
            + "/files/"
            + urllib.parse.quote(folder_id, safe="")
            + "?fields=id,mimeType,trashed",
            "ROUTE_BINDING_UNVERIFIED",
        )
        if (
            set(metadata) != {"id", "mimeType", "trashed"}
            or metadata.get("id") != folder_id
            or metadata.get("mimeType") != _FOLDER_MIME_TYPE
            or metadata.get("trashed") is not False
        ):
            raise HubError("ROUTE_BINDING_UNVERIFIED")
        return {
            "schema_version": "drive-exchange-route-verification-v1",
            "provider": "google-drive",
            "folder_id": folder_id,
            "drive_identity": identity,
            "credential_target": DEFAULT_CREDENTIAL_TARGET,
            "verified": True,
        }

    def _drive_identity(self, credential: dict) -> str:
        about = self._authorized_json(
            credential,
            _DRIVE_API + "/about?fields=user(permissionId)",
            "DRIVE_IDENTITY_UNAVAILABLE",
        )
        if set(about) != {"user"} or not isinstance(about["user"], dict):
            raise HubError("DRIVE_IDENTITY_UNAVAILABLE")
        permission_id = about["user"].get("permissionId")
        if (
            set(about["user"]) != {"permissionId"}
            or not isinstance(permission_id, str)
            or not permission_id
        ):
            raise HubError("DRIVE_IDENTITY_UNAVAILABLE")
        return "google-drive:" + permission_id

    def _recovery_credential(self, expected_drive_identity: str) -> dict:
        try:
            credential = self._load_credential()
            if self._drive_identity(credential) != expected_drive_identity:
                raise ValueError("drive identity mismatch")
            return credential
        except Exception as error:
            raise ConnectorAmbiguousError(
                {"code": "readOutcomeUnresolved", "message": "recovery drive identity unresolved"}
            ) from error

    def _load_credential(self) -> dict:
        raw = self._credential_store.read(DEFAULT_CREDENTIAL_TARGET)
        if raw is None:
            raise HubError("HUB_UNBOUND")
        credential = _json_no_duplicates(raw, "CREDENTIAL_VALUE_INVALID")
        allowed = {
            "schema_version",
            "access_token",
            "refresh_token",
            "scope",
            "token_type",
        }
        actual = frozenset(credential)
        if (
            actual not in {frozenset(allowed), frozenset(allowed | {"expires_at_unix"})}
            or credential.get("schema_version") != _CREDENTIAL_SCHEMA
            or not isinstance(credential.get("access_token"), str)
            or not credential["access_token"]
            or not isinstance(credential.get("refresh_token"), str)
            or not credential["refresh_token"]
            or credential.get("scope") != DRIVE_FILE_SCOPE
            or credential.get("token_type") != "Bearer"
            or (
                "expires_at_unix" in credential
                and (
                    type(credential["expires_at_unix"]) is not int
                    or credential["expires_at_unix"] <= 0
                )
            )
        ):
            raise HubError("CREDENTIAL_VALUE_INVALID")
        if credential.get("expires_at_unix", int(self._clock()) + 61) > int(
            self._clock()
        ) + 60:
            return credential
        return self._refresh_credential(credential)

    def _credential_from_token_response(self, token: dict) -> dict:
        required = {"access_token", "refresh_token", "scope", "token_type"}
        if (
            not required.issubset(token)
            or not isinstance(token.get("access_token"), str)
            or not token["access_token"]
            or not isinstance(token.get("refresh_token"), str)
            or not token["refresh_token"]
            or token.get("scope") != DRIVE_FILE_SCOPE
            or token.get("token_type") != "Bearer"
            or (
                "expires_in" in token
                and (type(token["expires_in"]) is not int or token["expires_in"] <= 0)
            )
        ):
            raise HubError("OAUTH_TOKEN_EXCHANGE_FAILED")
        credential = {
            "schema_version": _CREDENTIAL_SCHEMA,
            "access_token": token["access_token"],
            "refresh_token": token["refresh_token"],
            "scope": token["scope"],
            "token_type": token["token_type"],
        }
        if "expires_in" in token:
            credential["expires_at_unix"] = int(self._clock()) + token["expires_in"]
        return credential

    def _refresh_credential(self, credential: dict) -> dict:
        body = urllib.parse.urlencode(
            {
                "client_id": self._client_id,
                "client_secret": self._client_secret,
                "grant_type": "refresh_token",
                "refresh_token": credential["refresh_token"],
            }
        ).encode("ascii")
        token = self._request_json(
            method="POST",
            url=_TOKEN_ENDPOINT,
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            body=body,
            error_code="OAUTH_TOKEN_REFRESH_FAILED",
        )
        if (
            not {"access_token", "expires_in", "scope", "token_type"}.issubset(token)
            or not isinstance(token.get("access_token"), str)
            or not token["access_token"]
            or type(token.get("expires_in")) is not int
            or token["expires_in"] <= 0
            or token.get("scope") != DRIVE_FILE_SCOPE
            or token.get("token_type") != "Bearer"
        ):
            raise HubError("OAUTH_TOKEN_REFRESH_FAILED")
        refreshed = {
            "schema_version": _CREDENTIAL_SCHEMA,
            "access_token": token["access_token"],
            "expires_at_unix": int(self._clock()) + token["expires_in"],
            "refresh_token": credential["refresh_token"],
            "scope": DRIVE_FILE_SCOPE,
            "token_type": "Bearer",
        }
        self._credential_store.write(
            DEFAULT_CREDENTIAL_TARGET, canonical_json_bytes(refreshed)
        )
        return refreshed

    def _authorized_json(self, credential: dict, url: str, error_code: str) -> dict:
        return self._request_json(
            method="GET",
            url=url,
            headers={"Authorization": "Bearer " + credential["access_token"]},
            body=None,
            error_code=error_code,
        )

    def _request_json(
        self,
        *,
        method: str,
        url: str,
        headers: dict[str, str],
        body: bytes | None,
        error_code: str,
    ) -> dict:
        try:
            response = self._http_request(
                method=method, url=url, headers=headers, body=body
            )
        except Exception as error:
            raise HubError(error_code) from error
        if (
            not hasattr(response, "status")
            or not hasattr(response, "body")
            or response.status < 200
            or response.status >= 300
        ):
            if error_code == "OAUTH_TOKEN_EXCHANGE_FAILED":
                diagnostic = self._token_error_diagnostic(response)
                if diagnostic is not None:
                    raise OAuthTokenExchangeError(diagnostic)
            raise HubError(error_code)
        return self._response_json(response, error_code)

    @staticmethod
    def _token_error_diagnostic(response: object) -> dict[str, object] | None:
        status = getattr(response, "status", None)
        body = getattr(response, "body", None)
        if type(status) is not int or not isinstance(body, bytes):
            return None
        provider_error = "unavailable"
        description = ""
        try:
            payload = _json_no_duplicates(body, "OAUTH_TOKEN_ERROR_INVALID")
            raw_error = payload.get("error")
            if isinstance(raw_error, str) and raw_error in _TOKEN_PROVIDER_ERRORS:
                provider_error = raw_error
            raw_description = payload.get("error_description")
            if isinstance(raw_description, str) and len(raw_description) <= 4096:
                description = raw_description
        except HubError:
            pass

        lowered = description.casefold()
        parameter: str | None = None
        if "missing" in lowered or "required parameter" in lowered:
            category = "missing_parameter"
            match = _TOKEN_FIELD_NAME.search(lowered)
            if match is not None and match.group(1) in _TOKEN_PUBLIC_FIELDS:
                parameter = match.group(1)
        elif any(
            marker in lowered
            for marker in (
                "unsupported parameter",
                "unknown parameter",
                "unrecognized parameter",
                "parameter is not supported",
            )
        ):
            category = "unsupported_parameter"
        elif "redirect_uri" in lowered or "redirect uri" in lowered:
            category = "redirect_uri"
        elif provider_error in {"invalid_client", "unauthorized_client"} or any(
            marker in lowered
            for marker in (
                "client authentication",
                "client_id",
                "client id",
                "client_secret",
                "client secret",
            )
        ):
            category = "client_auth"
        elif provider_error == "invalid_grant" or any(
            marker in lowered
            for marker in (
                "code_verifier",
                "code verifier",
                "code_challenge",
                "code challenge",
                "authorization code",
                "auth code",
            )
        ):
            category = "pkce_or_code"
        else:
            category = "other"

        diagnostic: dict[str, object] = {
            "http_status": status,
            "provider_error": provider_error,
            "category": category,
        }
        if category == "missing_parameter" and parameter is not None:
            diagnostic["parameter"] = parameter
        return diagnostic

    @staticmethod
    def _response_json(response: object, error_code: str) -> dict:
        body = getattr(response, "body", None)
        if not isinstance(body, bytes):
            raise HubError(error_code)
        return _json_no_duplicates(body, error_code)

    @staticmethod
    def _provider_error(response: object) -> dict:
        code = "providerRejectedCreate"
        message = "Drive rejected create"
        try:
            payload = _json_no_duplicates(response.body, "DRIVE_PROVIDER_ERROR_INVALID")
            error = payload.get("error")
            if isinstance(error, dict):
                if isinstance(error.get("code"), (str, int)) and not isinstance(
                    error.get("code"), bool
                ):
                    code = str(error["code"])
                if isinstance(error.get("message"), str) and error["message"]:
                    message = error["message"]
        except HubError:
            pass
        return {
            "code": GoogleDriveAdapter._bounded_provider_error_field(
                code,
                default="providerRejectedCreate",
                max_utf8_bytes=_PROVIDER_ERROR_CODE_MAX_UTF8,
            ),
            "message": GoogleDriveAdapter._bounded_provider_error_field(
                message,
                default="Drive rejected create",
                max_utf8_bytes=_PROVIDER_ERROR_MESSAGE_MAX_UTF8,
            ),
        }

    @staticmethod
    def _bounded_provider_error_field(
        value: object, *, default: str, max_utf8_bytes: int
    ) -> str:
        if isinstance(value, (str, int)) and not isinstance(value, bool):
            candidate = unicodedata.normalize("NFC", str(value))
            try:
                encoded = candidate.encode("utf-8", errors="strict")
            except UnicodeEncodeError:
                return default
            if candidate and len(encoded) <= max_utf8_bytes:
                return candidate
        return default


def create_google_drive_adapter(
    *,
    hub_home: Path,
    credential_store: CredentialStore | None = None,
    browser_open: Callable[[str], object] = webbrowser.open,
    callback_server_factory: Callable[[], object] = _LoopbackCallbackServer,
    http_request: Callable[..., object] = _default_http_request,
    entropy: Callable[[int], bytes] = os.urandom,
    clock: Callable[[], float] = time.time,
) -> GoogleDriveAdapter:
    config_path = Path(hub_home) / _CLIENT_CONFIG_NAME
    try:
        info = config_path.lstat()
    except OSError as error:
        raise HubError("HUB_UNBOUND") from error
    if (
        not stat.S_ISREG(info.st_mode)
        or bool(
            getattr(info, "st_file_attributes", 0)
            & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
        )
        or info.st_size <= 0
        or info.st_size > 4096
    ):
        raise HubError("OAUTH_CLIENT_CONFIG_INVALID")
    try:
        raw = config_path.read_bytes()
    except OSError as error:
        raise HubError("OAUTH_CLIENT_CONFIG_INVALID") from error
    if len(raw) != info.st_size:
        raise HubError("OAUTH_CLIENT_CONFIG_INVALID")
    config = _json_no_duplicates(raw, "OAUTH_CLIENT_CONFIG_INVALID")
    if (
        set(config) != {"schema_version", "client_id", "client_secret"}
        or config.get("schema_version") != _CLIENT_CONFIG_SCHEMA
        or canonical_json_bytes(config) != raw
    ):
        raise HubError("OAUTH_CLIENT_CONFIG_INVALID")
    active_store = (
        credential_store
        if credential_store is not None
        else WindowsCredentialStore()
    )
    return GoogleDriveAdapter(
        client_id=config.get("client_id"),
        client_secret=config.get("client_secret"),
        credential_store=active_store,
        browser_open=browser_open,
        callback_server_factory=callback_server_factory,
        http_request=http_request,
        entropy=entropy,
        clock=clock,
    )


__all__ = [
    "DRIVE_FILE_SCOPE",
    "GoogleDriveAdapter",
    "OAuthTokenExchangeError",
    "create_google_drive_adapter",
]
