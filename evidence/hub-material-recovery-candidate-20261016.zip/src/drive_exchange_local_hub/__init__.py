from __future__ import annotations

import hashlib
import json
import os
import re
import sqlite3
import struct
import threading
import unicodedata
from datetime import datetime, timezone
from pathlib import Path


_FRAME_MAGIC = b"DXSTAGE\x00\x01"
_PROJECT_ID = re.compile(r"[a-z][a-z0-9-]{2,63}\Z")
_NAME = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}\Z")
_OPERATION_ID = re.compile(r"op_[0-9a-f]{32}\Z")
_DIGEST = re.compile(r"[0-9a-f]{64}\Z")
_RESERVED_NAMES = {
    "con",
    "prn",
    "aux",
    "nul",
    "clock$",
    *(f"com{number}" for number in range(1, 10)),
    *(f"lpt{number}" for number in range(1, 10)),
}
_REQUEST_KEYS = {
    "schema_version",
    "operation_id",
    "project_id",
    "project_identity",
    "route_name",
    "mode",
    "manifest_sha256",
    "frame_sha256",
}
_BOOTSTRAP_REQUEST_KEYS = {
    "schema_version",
    "operation_id",
    "request_id",
    "project_id",
    "project_identity",
    "config_sha256",
    "display_name",
    "topology_profile",
    "topology_profile_sha256",
}
_BOOTSTRAP_STATUS_REQUEST_KEYS = {
    "schema_version",
    "project_id",
    "project_identity",
    "config_sha256",
    "topology_profile",
    "topology_profile_sha256",
}
_CONNECTOR_ERROR_KEYS = {"code", "message"}
_CONNECTOR_ERROR_CODE_MAX_UTF8 = 256
_CONNECTOR_ERROR_MESSAGE_MAX_UTF8 = 2048
_BOOTSTRAP_OPERATION_STATES = {
    "SELECTING_PARENT",
    "CREATING_ROOT",
    "CREATING_FOLDERS",
    "CREATING_CATALOG",
    "CONFIGURING_CATALOG",
    "VERIFYING",
    "ACTIVATING",
    "AMBIGUOUS",
    "SUCCEEDED",
    "REJECTED",
}
_BOOTSTRAP_OBJECT_STATES = {"DISPATCHING", "CONFIRMED", "REJECTED"}
_BOOTSTRAP_STEP_STATES = {"DISPATCHING", "CONFIRMED", "REJECTED"}
_BOOTSTRAP_ISSUANCE_EDGES = {
    ("SELECTING_PARENT", "SELECTING_PARENT"),
    ("CREATING_ROOT", "CREATING_ROOT"),
    ("CREATING_ROOT", "CREATING_FOLDERS"),
    ("CREATING_FOLDERS", "CREATING_FOLDERS"),
    ("CREATING_FOLDERS", "CREATING_CATALOG"),
    ("CREATING_CATALOG", "CONFIGURING_CATALOG"),
    ("CONFIGURING_CATALOG", "VERIFYING"),
    ("VERIFYING", "VERIFYING"),
    ("VERIFYING", "ACTIVATING"),
    ("AMBIGUOUS", "AMBIGUOUS"),
}
_MANAGED_ROLE_ROUTES = {
    "handoffs": "handoffs",
    "raw-data": "raw_data",
    "analysis-outputs": "analysis_outputs",
}


class HubError(Exception):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


class ConnectorDefinitiveError(Exception):
    def __init__(self, error: dict) -> None:
        self.error = error
        super().__init__("DEFINITIVE_FAILURE")


class ConnectorAmbiguousError(Exception):
    def __init__(self, error: dict) -> None:
        self.error = error
        super().__init__("AMBIGUOUS")


def _canonical_text(value: object) -> str:
    if value is None:
        return "null"
    if value is True:
        return "true"
    if value is False:
        return "false"
    if type(value) is int:
        if abs(value) > 9_007_199_254_740_991:
            raise HubError("REQUEST_INVALID")
        return str(value)
    if isinstance(value, str):
        if unicodedata.normalize("NFC", value) != value:
            raise HubError("REQUEST_INVALID")
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"))
    if isinstance(value, list):
        return "[" + ",".join(_canonical_text(item) for item in value) + "]"
    if isinstance(value, dict):
        if not all(isinstance(key, str) for key in value):
            raise HubError("REQUEST_INVALID")
        ordered = sorted(value, key=lambda key: key.encode("utf-16-be"))
        return "{" + ",".join(
            _canonical_text(key) + ":" + _canonical_text(value[key])
            for key in ordered
        ) + "}"
    raise HubError("REQUEST_INVALID")


def canonical_json_bytes(value: object) -> bytes:
    return _canonical_text(value).encode("utf-8", errors="strict")


def _closed_connector_error(value: object) -> dict[str, str]:
    if not isinstance(value, dict) or set(value) != _CONNECTOR_ERROR_KEYS:
        raise ValueError("connector error shape")
    closed: dict[str, str] = {}
    for key, maximum in (
        ("code", _CONNECTOR_ERROR_CODE_MAX_UTF8),
        ("message", _CONNECTOR_ERROR_MESSAGE_MAX_UTF8),
    ):
        field = value[key]
        if not isinstance(field, str):
            raise ValueError("connector error field type")
        field = unicodedata.normalize("NFC", field)
        try:
            encoded = field.encode("utf-8", errors="strict")
        except UnicodeEncodeError as error:
            raise ValueError("connector error encoding") from error
        if not field or len(encoded) > maximum:
            raise ValueError("connector error field bound")
        closed[key] = field
    return closed


def project_identity_for_root(root: Path) -> str:
    canonical = Path(root).resolve(strict=True)
    normalized = os.path.normcase(str(canonical)).replace("\\", "/")
    payload = b"drive-exchange-local-project-v1\x00" + normalized.encode("utf-8")
    return "project-sha256:" + hashlib.sha256(payload).hexdigest()


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def _valid_managed_display_name(value: object) -> bool:
    return (
        isinstance(value, str)
        and 1 <= len(value) <= 100
        and unicodedata.normalize("NFC", value) == value
        and value == value.strip()
        and "/" not in value
        and "\\" not in value
        and not all(character == "." for character in value)
        and not any(
            unicodedata.category(character) == "Cc"
            or 0xD800 <= ord(character) <= 0xDFFF
            for character in value
        )
    )


def _require_bootstrap_issuance_edge(expected_state: str, state: str) -> None:
    if (expected_state, state) not in _BOOTSTRAP_ISSUANCE_EDGES:
        raise HubError("BOOTSTRAP_STATE_INVALID")


def _load_project_id(root: Path) -> str:
    canonical = Path(root).resolve(strict=True)
    marker = canonical / ".drive-exchange" / "project.json"
    try:
        raw = marker.read_bytes()
        value = json.loads(raw.decode("utf-8", errors="strict"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        raise HubError("PROJECT_MARKER_INVALID") from error
    if not isinstance(value, dict):
        raise HubError("PROJECT_MARKER_INVALID")
    project_id = value.get("project_id")
    if not isinstance(project_id, str) or _PROJECT_ID.fullmatch(project_id) is None:
        raise HubError("PROJECT_MARKER_INVALID")
    return project_id


class HubStore:
    def __init__(self, path: Path) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        with self._connect() as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS projects (
                    project_id TEXT PRIMARY KEY,
                    display_name TEXT NOT NULL,
                    canonical_root TEXT NOT NULL UNIQUE,
                    project_identity TEXT NOT NULL UNIQUE,
                    enabled INTEGER NOT NULL CHECK (enabled IN (0, 1)),
                    managed INTEGER NOT NULL DEFAULT 0 CHECK (managed IN (0, 1)),
                    created_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS routes (
                    project_id TEXT NOT NULL REFERENCES projects(project_id),
                    route_name TEXT NOT NULL,
                    folder_id TEXT NOT NULL,
                    enabled INTEGER NOT NULL CHECK (enabled IN (0, 1)),
                    verification_json BLOB NOT NULL,
                    created_at TEXT NOT NULL,
                    PRIMARY KEY (project_id, route_name)
                );
                CREATE TABLE IF NOT EXISTS operations (
                    operation_id TEXT PRIMARY KEY,
                    request_sha256 TEXT NOT NULL,
                    project_id TEXT NOT NULL,
                    route_name TEXT NOT NULL,
                    state TEXT NOT NULL,
                    connector_call_count INTEGER NOT NULL,
                    result_json BLOB,
                    error_json BLOB,
                    created_at TEXT NOT NULL,
                    completed_at TEXT
                );
                CREATE TABLE IF NOT EXISTS operation_items (
                    operation_id TEXT NOT NULL REFERENCES operations(operation_id),
                    item_index INTEGER NOT NULL,
                    source_path TEXT NOT NULL,
                    byte_size INTEGER NOT NULL,
                    source_sha256 TEXT NOT NULL,
                    state TEXT NOT NULL,
                    dispatch_attempt_count INTEGER NOT NULL DEFAULT 0,
                    remote_file_id TEXT,
                    remote_revision TEXT,
                    connector_result_json BLOB,
                    error_json BLOB,
                    PRIMARY KEY (operation_id, item_index)
                );
                CREATE TABLE IF NOT EXISTS receipts (
                    operation_id TEXT PRIMARY KEY REFERENCES operations(operation_id),
                    receipt_json BLOB NOT NULL,
                    byte_size INTEGER NOT NULL,
                    sha256 TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS bootstrap_operations (
                    operation_id TEXT PRIMARY KEY,
                    request_id TEXT NOT NULL,
                    request_sha256 TEXT NOT NULL,
                    request_json BLOB NOT NULL,
                    project_id TEXT NOT NULL,
                    project_identity TEXT NOT NULL,
                    state TEXT NOT NULL CHECK (state IN (
                        'SELECTING_PARENT','CREATING_ROOT','CREATING_FOLDERS',
                        'CREATING_CATALOG','CONFIGURING_CATALOG','VERIFYING',
                        'ACTIVATING','AMBIGUOUS','SUCCEEDED','REJECTED'
                    )),
                    remote_call_count INTEGER NOT NULL DEFAULT 0,
                    parent_json BLOB,
                    result_json BLOB,
                    error_json BLOB,
                    created_at TEXT NOT NULL,
                    completed_at TEXT
                );
                CREATE UNIQUE INDEX IF NOT EXISTS bootstrap_one_nonterminal_project
                ON bootstrap_operations(project_identity)
                WHERE state NOT IN ('SUCCEEDED', 'REJECTED');
                CREATE TABLE IF NOT EXISTS bootstrap_objects (
                    operation_id TEXT NOT NULL REFERENCES bootstrap_operations(operation_id),
                    ordinal INTEGER NOT NULL,
                    role TEXT NOT NULL,
                    name TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    parent_role TEXT,
                    remote_id TEXT,
                    state TEXT NOT NULL CHECK (state IN ('DISPATCHING','CONFIRMED','REJECTED')),
                    intent_json BLOB,
                    result_json BLOB,
                    PRIMARY KEY (operation_id, ordinal)
                );
                CREATE TABLE IF NOT EXISTS bootstrap_steps (
                    operation_id TEXT NOT NULL REFERENCES bootstrap_operations(operation_id),
                    step_ordinal INTEGER NOT NULL,
                    step_name TEXT NOT NULL,
                    mutation INTEGER NOT NULL CHECK (mutation IN (0, 1)),
                    state TEXT NOT NULL CHECK (state IN ('DISPATCHING','CONFIRMED','REJECTED')),
                    intent_json BLOB NOT NULL,
                    result_json BLOB,
                    PRIMARY KEY (operation_id, step_ordinal)
                );
                CREATE TABLE IF NOT EXISTS project_topologies (
                    project_id TEXT PRIMARY KEY,
                    project_identity TEXT NOT NULL UNIQUE,
                    profile_id TEXT NOT NULL,
                    profile_sha256 TEXT NOT NULL,
                    config_sha256 TEXT NOT NULL,
                    parent_folder_id TEXT NOT NULL,
                    project_root_id TEXT NOT NULL,
                    operation_id TEXT NOT NULL UNIQUE,
                    mapping_sha256 TEXT NOT NULL,
                    activated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS project_roles (
                    project_id TEXT NOT NULL REFERENCES project_topologies(project_id),
                    ordinal INTEGER NOT NULL,
                    role TEXT NOT NULL,
                    remote_id TEXT NOT NULL,
                    name TEXT NOT NULL,
                    kind TEXT NOT NULL,
                    PRIMARY KEY (project_id, role),
                    UNIQUE (project_id, ordinal),
                    UNIQUE (project_id, remote_id)
                );
                CREATE TABLE IF NOT EXISTS bootstrap_receipts (
                    operation_id TEXT PRIMARY KEY REFERENCES bootstrap_operations(operation_id),
                    receipt_json BLOB NOT NULL,
                    byte_size INTEGER NOT NULL,
                    sha256 TEXT NOT NULL
                );
                """
            )
            item_columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(operation_items)")
            }
            if "dispatch_attempt_count" not in item_columns:
                connection.execute(
                    "ALTER TABLE operation_items ADD COLUMN "
                    "dispatch_attempt_count INTEGER NOT NULL DEFAULT 0"
                )
            project_columns = {
                row["name"]
                for row in connection.execute("PRAGMA table_info(projects)")
            }
            if "managed" not in project_columns:
                newly_managed = [
                    row["project_id"]
                    for row in connection.execute(
                        "SELECT project_id FROM projects "
                        "WHERE canonical_root LIKE 'bootstrap:%'"
                    )
                ]
                connection.execute(
                    "ALTER TABLE projects ADD COLUMN managed INTEGER NOT NULL "
                    "DEFAULT 0 CHECK (managed IN (0, 1))"
                )
                connection.execute(
                    "UPDATE projects SET managed=1 WHERE canonical_root LIKE 'bootstrap:%'"
                )
                self._disable_unproven_managed_routes(connection, newly_managed)
            self._migrate_bootstrap_state_checks(connection)

    @staticmethod
    def _managed_route_role(route_name: str) -> str | None:
        if route_name == "standard":
            return "reports"
        return _MANAGED_ROLE_ROUTES.get(route_name)

    @classmethod
    def _managed_route_is_proven(
        cls,
        connection: sqlite3.Connection,
        *,
        project_id: str,
        route_name: str,
        folder_id: str,
    ) -> bool:
        role = cls._managed_route_role(route_name)
        if role is None:
            return False
        row = connection.execute(
            "SELECT r.remote_id FROM project_topologies AS t "
            "JOIN project_roles AS r ON r.project_id=t.project_id "
            "WHERE t.project_id=? AND r.role=?",
            (project_id, role),
        ).fetchone()
        return row is not None and row["remote_id"] == folder_id

    @classmethod
    def _disable_unproven_managed_routes(
        cls, connection: sqlite3.Connection, project_ids: list[str]
    ) -> None:
        for project_id in project_ids:
            routes = connection.execute(
                "SELECT route_name, folder_id FROM routes WHERE project_id=?",
                (project_id,),
            ).fetchall()
            for route in routes:
                if not cls._managed_route_is_proven(
                    connection,
                    project_id=project_id,
                    route_name=route["route_name"],
                    folder_id=route["folder_id"],
                ):
                    connection.execute(
                        "UPDATE routes SET enabled=0 "
                        "WHERE project_id=? AND route_name=?",
                        (project_id, route["route_name"]),
                    )

    @staticmethod
    def _migrate_bootstrap_state_checks(connection: sqlite3.Connection) -> None:
        constraints = {
            "bootstrap_operations": tuple(sorted(_BOOTSTRAP_OPERATION_STATES)),
            "bootstrap_objects": tuple(sorted(_BOOTSTRAP_OBJECT_STATES)),
            "bootstrap_steps": tuple(sorted(_BOOTSTRAP_STEP_STATES)),
        }
        for table, states in constraints.items():
            columns = {
                row["name"]
                for row in connection.execute(f"PRAGMA table_info({table})")
            }
            if "state_closed" in columns:
                continue
            schema = connection.execute(
                "SELECT sql FROM sqlite_master WHERE type='table' AND name=?",
                (table,),
            ).fetchone()
            if schema is not None and "state TEXT NOT NULL CHECK" in schema["sql"]:
                continue
            allowed = ",".join("'" + state + "'" for state in states)
            connection.execute(
                f"ALTER TABLE {table} ADD COLUMN state_closed INTEGER "
                f"CHECK (state IN ({allowed}))"
            )

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path)
        connection.row_factory = sqlite3.Row
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=FULL")
        return connection

    def register_project(self, *, root: Path, display_name: str) -> dict:
        canonical = Path(root).resolve(strict=True)
        project_id = _load_project_id(canonical)
        if not isinstance(display_name, str) or not display_name.strip():
            raise HubError("PROJECT_REGISTRATION_INVALID")
        identity = project_identity_for_root(canonical)
        try:
            with self._connect() as connection:
                connection.execute(
                    "INSERT INTO projects "
                    "(project_id, display_name, canonical_root, project_identity, "
                    "enabled, managed, created_at) VALUES (?, ?, ?, ?, 1, 0, ?)",
                    (project_id, display_name, str(canonical), identity, _utc_now()),
                )
        except sqlite3.IntegrityError as error:
            raise HubError("PROJECT_REGISTRATION_CONFLICT") from error
        return self.show_project(project_id)

    def show_project(self, project_id: str) -> dict:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM projects WHERE project_id=?", (project_id,)
            ).fetchone()
        if row is None:
            raise HubError("HUB_UNBOUND")
        return dict(row)

    def rebind_project_root(self, *, project_id: str, root: Path) -> dict:
        canonical = Path(root).resolve(strict=True)
        if _load_project_id(canonical) != project_id:
            raise HubError("PROJECT_ROOT_MISMATCH")
        identity = project_identity_for_root(canonical)
        try:
            with self._connect() as connection:
                cursor = connection.execute(
                    "UPDATE projects SET canonical_root=?, project_identity=? WHERE project_id=?",
                    (str(canonical), identity, project_id),
                )
                if cursor.rowcount != 1:
                    raise HubError("HUB_UNBOUND")
        except sqlite3.IntegrityError as error:
            raise HubError("PROJECT_REGISTRATION_CONFLICT") from error
        return self.show_project(project_id)

    def bind_route(
        self,
        *,
        project_id: str,
        route_name: str,
        folder_id: str,
        verification: dict,
    ) -> dict:
        if _NAME.fullmatch(route_name) is None or not isinstance(folder_id, str):
            raise HubError("ROUTE_BINDING_INVALID")
        if (
            not isinstance(verification, dict)
            or verification.get("folder_id") != folder_id
            or verification.get("verified") is not True
        ):
            raise HubError("ROUTE_BINDING_UNVERIFIED")
        verification_bytes = canonical_json_bytes(verification)
        try:
            with self._connect() as connection:
                project = connection.execute(
                    "SELECT managed FROM projects WHERE project_id=?",
                    (project_id,),
                ).fetchone()
                if project is None:
                    raise HubError("HUB_UNBOUND")
                if project["managed"] == 1:
                    raise HubError("ROUTE_ROLE_DENIED")
                connection.execute(
                    "INSERT INTO routes VALUES (?, ?, ?, 1, ?, ?)",
                    (
                        project_id,
                        route_name,
                        folder_id,
                        verification_bytes,
                        _utc_now(),
                    ),
                )
        except sqlite3.IntegrityError as error:
            raise HubError("ROUTE_BINDING_CONFLICT") from error
        return self.show_route(project_id, route_name)

    def show_route(self, project_id: str, route_name: str) -> dict:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT routes.*, projects.managed FROM routes "
                "JOIN projects ON projects.project_id=routes.project_id "
                "WHERE routes.project_id=? AND routes.route_name=?",
                (project_id, route_name),
            ).fetchone()
            if row is None or row["enabled"] != 1:
                raise HubError("ROUTE_UNBOUND")
            if row["managed"] == 1 and not self._managed_route_is_proven(
                connection,
                project_id=project_id,
                route_name=route_name,
                folder_id=row["folder_id"],
            ):
                raise HubError("ROUTE_ROLE_DENIED")
            result = dict(row)
        result.pop("managed")
        result["verification"] = json.loads(result.pop("verification_json"))
        return result

    def disable_route(self, project_id: str, route_name: str) -> dict:
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE routes SET enabled=0 WHERE project_id=? AND route_name=?",
                (project_id, route_name),
            )
            if cursor.rowcount != 1:
                raise HubError("ROUTE_UNBOUND")
            row = connection.execute(
                "SELECT * FROM routes WHERE project_id=? AND route_name=?",
                (project_id, route_name),
            ).fetchone()
        assert row is not None
        result = dict(row)
        result["verification"] = json.loads(result.pop("verification_json"))
        return result

    def enabled_folder_ids(self) -> set[str]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT DISTINCT folder_id FROM routes WHERE enabled=1"
            ).fetchall()
        return {row["folder_id"] for row in rows}

    def get_receipt(self, operation_id: str) -> dict:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT receipt_json FROM receipts WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
        if row is None:
            raise HubError("OPERATION_NOT_FOUND")
        return json.loads(row["receipt_json"])

    def stored_operation(
        self, operation_id: str, request_sha256: str
    ) -> dict | None:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM operations WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
        if row is None:
            return None
        if row["request_sha256"] != request_sha256:
            raise HubError("OPERATION_ID_CONFLICT")
        return dict(row)

    def recover_dispatching_as_ambiguous(
        self, operation_id: str, result: dict, error: dict
    ) -> dict:
        result_bytes = canonical_json_bytes(result)
        error_bytes = canonical_json_bytes(error)
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = connection.execute(
                "SELECT state, result_json FROM operations WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if row is None:
                raise HubError("OPERATION_NOT_FOUND")
            if row["result_json"] is not None:
                return json.loads(row["result_json"])
            connection.execute(
                "UPDATE operations SET state='AMBIGUOUS', result_json=?, error_json=?, completed_at=? WHERE operation_id=? AND state='DISPATCHING'",
                (result_bytes, error_bytes, _utc_now(), operation_id),
            )
            connection.execute(
                "UPDATE operation_items SET state='AMBIGUOUS', error_json=? "
                "WHERE operation_id=? AND state='DISPATCHING'",
                (error_bytes, operation_id),
            )
        return result

    def route_for_recovery(self, project_id: str, route_name: str) -> dict:
        row = self.show_route(project_id, route_name)
        return {
            "folder_id": row["folder_id"],
            "verification": row["verification"],
        }

    def begin_bootstrap(self, request: dict, request_bytes: bytes) -> dict | None:
        request_sha256 = hashlib.sha256(request_bytes).hexdigest()
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            existing = connection.execute(
                "SELECT * FROM bootstrap_operations WHERE operation_id=?",
                (request["operation_id"],),
            ).fetchone()
            if existing is not None:
                if (
                    existing["request_sha256"] != request_sha256
                    or existing["request_json"] != request_bytes
                ):
                    raise HubError("OPERATION_ID_CONFLICT")
                return dict(existing)
            canonical_root = "bootstrap:" + request["project_identity"]
            project = connection.execute(
                "SELECT * FROM projects WHERE project_id=?",
                (request["project_id"],),
            ).fetchone()
            if project is None:
                try:
                    connection.execute(
                        "INSERT INTO projects "
                        "(project_id, display_name, canonical_root, project_identity, "
                        "enabled, managed, created_at) VALUES (?, ?, ?, ?, 1, 1, ?)",
                        (
                            request["project_id"], request["display_name"],
                            canonical_root, request["project_identity"], _utc_now(),
                        ),
                    )
                except sqlite3.IntegrityError as error:
                    raise HubError("PROJECT_REGISTRATION_CONFLICT") from error
            elif (
                project["project_identity"] != request["project_identity"]
                or project["display_name"] != request["display_name"]
                or project["canonical_root"] != canonical_root
                or project["enabled"] != 1
                or project["managed"] != 1
            ):
                raise HubError("PROJECT_REGISTRATION_CONFLICT")
            claimed = connection.execute(
                "SELECT operation_id FROM bootstrap_operations WHERE "
                "project_identity=? AND state NOT IN ('SUCCEEDED','REJECTED')",
                (request["project_identity"],),
            ).fetchone()
            if claimed is not None:
                raise HubError("BOOTSTRAP_PROJECT_CLAIMED")
            try:
                connection.execute(
                    "INSERT INTO bootstrap_operations "
                    "(operation_id, request_id, request_sha256, request_json, "
                    "project_id, project_identity, state, created_at) "
                    "VALUES (?, ?, ?, ?, ?, ?, 'SELECTING_PARENT', ?)",
                    (
                        request["operation_id"],
                        request["request_id"],
                        request_sha256,
                        request_bytes,
                        request["project_id"],
                        request["project_identity"],
                        _utc_now(),
                    ),
                )
            except sqlite3.IntegrityError as error:
                raise HubError("BOOTSTRAP_PROJECT_CLAIMED") from error
        return None

    def replayed_bootstrap(
        self, operation_id: str, request_bytes: bytes
    ) -> dict | None:
        request_sha256 = hashlib.sha256(request_bytes).hexdigest()
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM bootstrap_operations WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
        if row is None:
            return None
        if row["request_sha256"] != request_sha256 or row["request_json"] != request_bytes:
            raise HubError("OPERATION_ID_CONFLICT")
        return dict(row)

    def bootstrap_transition(
        self, operation_id: str, *, expected_state: str, state: str
    ) -> None:
        _require_bootstrap_issuance_edge(expected_state, state)
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE bootstrap_operations SET state=? WHERE operation_id=? AND state=?",
                (state, operation_id, expected_state),
            )
            if cursor.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")

    def bootstrap_set_parent(self, operation_id: str, parent: dict) -> None:
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE bootstrap_operations SET parent_json=?, state='CREATING_ROOT' "
                "WHERE operation_id=? AND state='SELECTING_PARENT'",
                (canonical_json_bytes(parent), operation_id),
            )
            if cursor.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")

    def bootstrap_record_intent(
        self,
        *,
        operation_id: str,
        ordinal: int,
        role: str,
        name: str,
        kind: str,
        parent_role: str | None,
        intent: dict,
        expected_state: str | None = None,
        state: str | None = None,
    ) -> None:
        remote_id = intent.get("remote_id")
        if remote_id is not None and (not isinstance(remote_id, str) or not remote_id):
            raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")
        expected_state = expected_state or (
            "CREATING_ROOT" if role == "project_root" else
            "CREATING_FOLDERS" if kind == "folder" else "CREATING_CATALOG"
        )
        state = state or expected_state
        _require_bootstrap_issuance_edge(expected_state, state)
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            operation = connection.execute(
                "UPDATE bootstrap_operations SET remote_call_count=remote_call_count+1, "
                "state=? WHERE operation_id=? AND state=?",
                (state, operation_id, expected_state),
            )
            if operation.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")
            try:
                connection.execute(
                "INSERT INTO bootstrap_objects "
                "(operation_id, ordinal, role, name, kind, parent_role, remote_id, "
                "state, intent_json, result_json) VALUES (?, ?, ?, ?, ?, ?, ?, "
                "'DISPATCHING', ?, NULL)",
                (
                    operation_id, ordinal, role, name, kind, parent_role,
                    remote_id, canonical_json_bytes(intent),
                ),
                )
            except sqlite3.IntegrityError as error:
                raise HubError("BOOTSTRAP_STATE_INVALID") from error

    def bootstrap_record_object(
        self, operation_id: str, ordinal: int, remote: dict
    ) -> None:
        remote_id = remote.get("id")
        if not isinstance(remote_id, str):
            raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE bootstrap_objects SET remote_id=?, state='CONFIRMED', "
                "result_json=? WHERE operation_id=? AND ordinal=? AND state='DISPATCHING'",
                (remote_id, canonical_json_bytes(remote), operation_id, ordinal),
            )
            if cursor.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")

    def bootstrap_reject_object(self, operation_id: str, ordinal: int) -> None:
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE bootstrap_objects SET state='REJECTED' "
                "WHERE operation_id=? AND ordinal=? AND state='DISPATCHING'",
                (operation_id, ordinal),
            )
            if cursor.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")

    def bootstrap_record_step_intent(
        self,
        *,
        operation_id: str,
        step_ordinal: int,
        step_name: str,
        mutation: bool,
        expected_state: str,
        state: str,
        intent: dict,
    ) -> None:
        _require_bootstrap_issuance_edge(expected_state, state)
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            try:
                connection.execute(
                    "INSERT INTO bootstrap_steps "
                    "(operation_id, step_ordinal, step_name, mutation, state, "
                    "intent_json, result_json) VALUES "
                    "(?, ?, ?, ?, 'DISPATCHING', ?, NULL)",
                    (
                        operation_id, step_ordinal, step_name, int(mutation),
                        canonical_json_bytes(intent),
                    ),
                )
            except sqlite3.IntegrityError as error:
                raise HubError("BOOTSTRAP_STATE_INVALID") from error
            cursor = connection.execute(
                "UPDATE bootstrap_operations SET remote_call_count=remote_call_count+1, "
                "state=? WHERE operation_id=? AND state=?",
                (state, operation_id, expected_state),
            )
            if cursor.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")

    def bootstrap_record_step_result(
        self, operation_id: str, step_ordinal: int, result: object
    ) -> None:
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE bootstrap_steps SET state='CONFIRMED', result_json=? "
                "WHERE operation_id=? AND step_ordinal=? AND state='DISPATCHING'",
                (canonical_json_bytes(result), operation_id, step_ordinal),
            )
            if cursor.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")

    def bootstrap_reject_step(self, operation_id: str, step_ordinal: int) -> None:
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE bootstrap_steps SET state='REJECTED' "
                "WHERE operation_id=? AND step_ordinal=? AND state='DISPATCHING'",
                (operation_id, step_ordinal),
            )
            if cursor.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")

    def bootstrap_residue(self, operation_id: str) -> list[dict]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT ordinal, role, remote_id FROM bootstrap_objects "
                "WHERE operation_id=? AND state IN ('DISPATCHING','CONFIRMED') "
                "AND remote_id IS NOT NULL ORDER BY ordinal",
                (operation_id,),
            ).fetchall()
        return [
            {"ordinal": row["ordinal"], "role": row["role"], "remote_id": row["remote_id"]}
            for row in rows
        ]

    def bootstrap_snapshot(self, operation_id: str) -> dict:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT * FROM bootstrap_operations WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
        if row is None:
            raise HubError("OPERATION_NOT_FOUND")
        return dict(row)

    def bootstrap_object_rows(self, operation_id: str) -> list[dict]:
        with self._connect() as connection:
            rows = connection.execute(
                "SELECT * FROM bootstrap_objects WHERE operation_id=? "
                "AND state IN ('DISPATCHING','CONFIRMED') ORDER BY ordinal",
                (operation_id,),
            ).fetchall()
        return [dict(row) for row in rows]

    def bootstrap_step_result(self, operation_id: str, step_name: str) -> dict:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT result_json FROM bootstrap_steps WHERE operation_id=? "
                "AND step_name=? AND state='CONFIRMED' ORDER BY step_ordinal DESC LIMIT 1",
                (operation_id, step_name),
            ).fetchone()
        if row is None or row["result_json"] is None:
            raise HubError("BOOTSTRAP_STATE_INVALID")
        return json.loads(row["result_json"])

    def bootstrap_step_intent(self, operation_id: str, step_name: str) -> dict:
        with self._connect() as connection:
            row = connection.execute(
                "SELECT intent_json FROM bootstrap_steps WHERE operation_id=? "
                "AND step_name=? AND state IN ('DISPATCHING','CONFIRMED') "
                "ORDER BY step_ordinal DESC LIMIT 1",
                (operation_id, step_name),
            ).fetchone()
        if row is None or row["intent_json"] is None:
            raise HubError("BOOTSTRAP_STATE_INVALID")
        return json.loads(row["intent_json"])

    def bootstrap_resume_context(self, operation_id: str) -> dict:
        with self._connect() as connection:
            operation = connection.execute(
                "SELECT * FROM bootstrap_operations WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if operation is None:
                raise HubError("OPERATION_NOT_FOUND")
            objects = connection.execute(
                "SELECT * FROM bootstrap_objects WHERE operation_id=? ORDER BY ordinal",
                (operation_id,),
            ).fetchall()
            steps = connection.execute(
                "SELECT * FROM bootstrap_steps WHERE operation_id=? ORDER BY step_ordinal",
                (operation_id,),
            ).fetchall()
            topology = connection.execute(
                "SELECT 1 FROM project_topologies WHERE project_id=?",
                (operation["project_id"],),
            ).fetchone()
            receipt = connection.execute(
                "SELECT 1 FROM bootstrap_receipts WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            routes = connection.execute(
                "SELECT 1 FROM routes WHERE project_id=? LIMIT 1",
                (operation["project_id"],),
            ).fetchone()
        apply_steps = [
            row for row in steps if row["step_name"] == "apply_catalog_template"
        ]
        catalog_state_allowed = False
        if len(apply_steps) == 1:
            apply_step = apply_steps[0]
            later = [row for row in steps if row["step_ordinal"] > apply_step["step_ordinal"]]
            if apply_step["state"] == "REJECTED":
                catalog_state_allowed = apply_step["result_json"] is None and not later
            elif apply_step["state"] == "CONFIRMED":
                # Admit only known read prefixes before any rename, including
                # a previously interrupted explicit recovery. No write replay.
                verification_names = ("get_object",) * 6 + ("read_catalog",)
                recovery_names = (
                    "resume_list_operation_objects",
                    *("resume_get_" + row["role"] for row in objects),
                    "resume_inspect_catalog",
                )

                def valid_read_prefix(reads, names):
                    return (
                        1 <= len(reads) <= len(names)
                        and tuple(row["step_name"] for row in reads) == names[:len(reads)]
                        and all(row["mutation"] == 0 for row in reads)
                        and all(row["state"] == "CONFIRMED" for row in reads[:-1])
                        and reads[-1]["state"] in {"CONFIRMED", "DISPATCHING", "REJECTED"}
                    )

                boundaries = [
                    index for index, row in enumerate(later)
                    if row["step_name"] == "resume_list_operation_objects"
                ]
                first_recovery = boundaries[0] if boundaries else len(later)
                catalog_state_allowed = (
                    apply_step["result_json"] is not None
                    and valid_read_prefix(later[:first_recovery], verification_names)
                    and all(
                        valid_read_prefix(later[start:end], recovery_names)
                        for start, end in zip(boundaries, boundaries[1:] + [len(later)])
                    )
                )
        if (
            operation["state"] != "AMBIGUOUS"
            or operation["parent_json"] is None
            or operation["result_json"] is None
            or len(objects) != 7
            or any(
                row["state"] != "CONFIRMED"
                or not isinstance(row["remote_id"], str)
                or not row["remote_id"]
                or row["intent_json"] is None
                or row["result_json"] is None
                for row in objects
            )
            or len(apply_steps) != 1
            or apply_steps[0]["mutation"] != 1
            or not catalog_state_allowed
            or topology is not None
            or receipt is not None
            or routes is not None
        ):
            raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
        return {
            "operation": dict(operation),
            "objects": [dict(row) for row in objects],
            "apply_step": dict(apply_steps[0]),
            "original_steps": [dict(row) for row in steps],
            "next_step_ordinal": max(
                (row["step_ordinal"] for row in steps), default=-1
            )
            + 1,
        }

    def bootstrap_continue_confirmed_catalog(
        self,
        operation_id: str,
        *,
        original_context: dict,
        expected_recovery_steps: tuple[str, ...],
    ) -> None:
        """Advance only an unchanged snapshot after fresh successful reads."""
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            operation = connection.execute(
                "SELECT * FROM bootstrap_operations WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            original_steps = original_context["original_steps"]
            recorded = [dict(row) for row in connection.execute(
                "SELECT * FROM bootstrap_steps WHERE operation_id=? ORDER BY step_ordinal",
                (operation_id,),
            ).fetchall()]
            recovery = recorded[len(original_steps):]
            objects = [dict(row) for row in connection.execute(
                "SELECT * FROM bootstrap_objects WHERE operation_id=? ORDER BY ordinal",
                (operation_id,),
            ).fetchall()]
            expected_operation = dict(original_context["operation"])
            expected_operation["remote_call_count"] += len(expected_recovery_steps)
            topology = connection.execute(
                "SELECT 1 FROM project_topologies WHERE project_id=?",
                (expected_operation["project_id"],),
            ).fetchone()
            receipt = connection.execute(
                "SELECT 1 FROM bootstrap_receipts WHERE operation_id=?", (operation_id,),
            ).fetchone()
            routes = connection.execute(
                "SELECT 1 FROM routes WHERE project_id=? LIMIT 1",
                (expected_operation["project_id"],),
            ).fetchone()
            if (
                operation is None or operation["state"] != "AMBIGUOUS"
                or dict(operation) != expected_operation
                or objects != original_context["objects"]
                or topology is not None or receipt is not None or routes is not None
                or not original_steps
                or recorded[:len(original_steps)] != original_steps
                or not expected_recovery_steps
                or tuple(row["step_name"] for row in recovery) != expected_recovery_steps
                or any(row["mutation"] != 0 or row["state"] != "CONFIRMED" for row in recovery)
            ):
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
            changed = connection.execute(
                "UPDATE bootstrap_operations SET state='CONFIGURING_CATALOG' "
                "WHERE operation_id=? AND state='AMBIGUOUS'", (operation_id,),
            )
            if changed.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")

    def bootstrap_reissue_rejected_step(
        self,
        operation_id: str,
        *,
        step_name: str,
        expected_intent: dict,
        state: str,
        expected_recovery_steps: tuple[str, ...] = (),
    ) -> int:
        if step_name != "apply_catalog_template" or state != "CONFIGURING_CATALOG":
            raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
        expected_bytes = canonical_json_bytes(expected_intent)
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            operation = connection.execute(
                "SELECT state FROM bootstrap_operations WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            rows = connection.execute(
                "SELECT * FROM bootstrap_steps WHERE operation_id=? AND step_name=?",
                (operation_id, step_name),
            ).fetchall()
            if len(rows) != 1:
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
            target = rows[0]
            recovery = connection.execute(
                "SELECT step_name, mutation, state FROM bootstrap_steps "
                "WHERE operation_id=? AND step_ordinal>? ORDER BY step_ordinal",
                (operation_id, target["step_ordinal"]),
            ).fetchall()
            if (
                operation is None
                or operation["state"] != "AMBIGUOUS"
                or target["mutation"] != 1
                or target["state"] != "REJECTED"
                or target["result_json"] is not None
                or target["intent_json"] != expected_bytes
                or tuple(row["step_name"] for row in recovery)
                != expected_recovery_steps
                or any(
                    row["mutation"] != 0 or row["state"] != "CONFIRMED"
                    for row in recovery
                )
            ):
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
            step = connection.execute(
                "UPDATE bootstrap_steps SET state='DISPATCHING' "
                "WHERE operation_id=? AND step_ordinal=? AND state='REJECTED'",
                (operation_id, target["step_ordinal"]),
            )
            operation_update = connection.execute(
                "UPDATE bootstrap_operations SET state=?, "
                "remote_call_count=remote_call_count+1 WHERE operation_id=? "
                "AND state='AMBIGUOUS'",
                (state, operation_id),
            )
            if step.rowcount != 1 or operation_update.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")
        return target["step_ordinal"]

    def bootstrap_confirm_rejected_step_by_readback(
        self,
        operation_id: str,
        *,
        step_name: str,
        expected_intent: dict,
        result: dict,
        state: str,
        expected_recovery_steps: tuple[str, ...],
    ) -> None:
        if step_name != "apply_catalog_template" or state != "CONFIGURING_CATALOG":
            raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
        expected_bytes = canonical_json_bytes(expected_intent)
        result_bytes = canonical_json_bytes(result)
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            operation = connection.execute(
                "SELECT state FROM bootstrap_operations WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            rows = connection.execute(
                "SELECT * FROM bootstrap_steps WHERE operation_id=? AND step_name=?",
                (operation_id, step_name),
            ).fetchall()
            if len(rows) != 1:
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
            target = rows[0]
            recovery = connection.execute(
                "SELECT step_name, mutation, state FROM bootstrap_steps "
                "WHERE operation_id=? AND step_ordinal>? ORDER BY step_ordinal",
                (operation_id, target["step_ordinal"]),
            ).fetchall()
            if (
                operation is None
                or operation["state"] != "AMBIGUOUS"
                or target["mutation"] != 1
                or target["state"] != "REJECTED"
                or target["result_json"] is not None
                or target["intent_json"] != expected_bytes
                or tuple(row["step_name"] for row in recovery)
                != expected_recovery_steps
                or any(
                    row["mutation"] != 0 or row["state"] != "CONFIRMED"
                    for row in recovery
                )
            ):
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
            step = connection.execute(
                "UPDATE bootstrap_steps SET state='CONFIRMED', result_json=? "
                "WHERE operation_id=? AND step_ordinal=? AND state='REJECTED'",
                (result_bytes, operation_id, target["step_ordinal"]),
            )
            operation_update = connection.execute(
                "UPDATE bootstrap_operations SET state=? WHERE operation_id=? "
                "AND state='AMBIGUOUS'",
                (state, operation_id),
            )
            if step.rowcount != 1 or operation_update.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")

    def bootstrap_confirm_reconciled_object(
        self, operation_id: str, ordinal: int, remote: dict
    ) -> None:
        remote_id = remote.get("id")
        if not isinstance(remote_id, str) or not remote_id:
            raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE bootstrap_objects SET remote_id=?, state='CONFIRMED', result_json=? "
                "WHERE operation_id=? AND ordinal=? AND state='DISPATCHING'",
                (remote_id, canonical_json_bytes(remote), operation_id, ordinal),
            )
            if cursor.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")

    def bootstrap_confirm_reconciled_objects(
        self, operation_id: str, objects: list[dict]
    ) -> None:
        updates: list[tuple[int, str, bytes]] = []
        for item in objects:
            remote = item.get("remote") if isinstance(item, dict) else None
            ordinal = item.get("ordinal") if isinstance(item, dict) else None
            if (
                type(ordinal) is not int
                or not isinstance(remote, dict)
                or not isinstance(remote.get("id"), str)
                or not remote["id"]
            ):
                raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")
            updates.append((ordinal, remote["id"], canonical_json_bytes(remote)))
        if len({ordinal for ordinal, _, _ in updates}) != len(updates):
            raise HubError("BOOTSTRAP_STATE_INVALID")
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            for ordinal, remote_id, result_json in updates:
                cursor = connection.execute(
                    "UPDATE bootstrap_objects SET remote_id=?, state='CONFIRMED', result_json=? "
                    "WHERE operation_id=? AND ordinal=? AND state='DISPATCHING'",
                    (remote_id, result_json, operation_id, ordinal),
                )
                if cursor.rowcount != 1:
                    raise HubError("BOOTSTRAP_STATE_INVALID")

    def bootstrap_confirm_reconciled_step(
        self, operation_id: str, step_name: str, result: dict
    ) -> None:
        with self._connect() as connection:
            cursor = connection.execute(
                "UPDATE bootstrap_steps SET state='CONFIRMED', result_json=? "
                "WHERE operation_id=? AND step_name=? AND state='DISPATCHING'",
                (canonical_json_bytes(result), operation_id, step_name),
            )
            if cursor.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")

    def active_bootstrap_result(self, request: dict) -> dict | None:
        with self._connect() as connection:
            topology = connection.execute(
                "SELECT * FROM project_topologies WHERE project_id=?",
                (request["project_id"],),
            ).fetchone()
            if topology is None:
                return None
            project = connection.execute(
                "SELECT display_name FROM projects WHERE project_id=?",
                (request["project_id"],),
            ).fetchone()
            if (
                topology["project_identity"] != request["project_identity"]
                or topology["profile_id"] != request["topology_profile"]
                or topology["profile_sha256"] != request["topology_profile_sha256"]
                or topology["config_sha256"] != request["config_sha256"]
                or project is None
                or project["display_name"] != request["display_name"]
            ):
                raise HubError("BOOTSTRAP_ACTIVE_CONFLICT")
            operation = connection.execute(
                "SELECT result_json FROM bootstrap_operations WHERE operation_id=?",
                (topology["operation_id"],),
            ).fetchone()
        if operation is None or operation["result_json"] is None:
            raise HubError("BOOTSTRAP_STATE_INVALID")
        result = json.loads(operation["result_json"])
        result["state"] = "ALREADY_BOOTSTRAPPED"
        return result

    def show_topology(self, project_id: str) -> dict:
        with self._connect() as connection:
            topology = connection.execute(
                "SELECT * FROM project_topologies WHERE project_id=?",
                (project_id,),
            ).fetchone()
            roles = connection.execute(
                "SELECT ordinal, role, remote_id, name, kind FROM project_roles "
                "WHERE project_id=? ORDER BY ordinal",
                (project_id,),
            ).fetchall()
        if topology is None:
            raise HubError("TOPOLOGY_UNBOUND")
        return {
            "schema_version": "drive-exchange-topology-status-v1",
            "project_id": project_id,
            "project_identity": topology["project_identity"],
            "profile_id": topology["profile_id"],
            "profile_sha256": topology["profile_sha256"],
            "config_sha256": topology["config_sha256"],
            "parent_folder_id": topology["parent_folder_id"],
            "project_root_id": topology["project_root_id"],
            "operation_id": topology["operation_id"],
            "mapping_sha256": topology["mapping_sha256"],
            "roles": [dict(row) for row in roles],
        }

    def client_topology_status(self, request: dict) -> dict:
        with self._connect() as connection:
            topology = connection.execute(
                "SELECT * FROM project_topologies WHERE project_id=?",
                (request["project_id"],),
            ).fetchone()
            if topology is not None:
                if (
                    topology["project_identity"] != request["project_identity"]
                    or topology["profile_id"] != request["topology_profile"]
                    or topology["profile_sha256"] != request["topology_profile_sha256"]
                    or topology["config_sha256"] != request["config_sha256"]
                ):
                    raise HubError("BOOTSTRAP_ACTIVE_CONFLICT")
                roles = connection.execute(
                    "SELECT role FROM project_roles WHERE project_id=? ORDER BY ordinal",
                    (request["project_id"],),
                ).fetchall()
                routes = connection.execute(
                    "SELECT route_name FROM routes WHERE project_id=? AND enabled=1 ORDER BY route_name",
                    (request["project_id"],),
                ).fetchall()
                return {
                    "schema_version": "drive-exchange-bootstrap-status-result-v1",
                    "project_id": request["project_id"],
                    "topology_state": "TOPOLOGY_ACTIVE",
                    "operation_id": topology["operation_id"],
                    "active_routes": [row["route_name"] for row in routes],
                    "role_names": [row["role"] for row in roles],
                }
            operation = connection.execute(
                "SELECT operation_id, state FROM bootstrap_operations WHERE "
                "project_identity=? ORDER BY created_at DESC LIMIT 1",
                (request["project_identity"],),
            ).fetchone()
        if operation is None or operation["state"] == "REJECTED":
            state = "HUB_UNBOUND"
            operation_id = None
        elif operation["state"] == "AMBIGUOUS":
            state = "BOOTSTRAP_AMBIGUOUS"
            operation_id = operation["operation_id"]
        else:
            state = "BOOTSTRAP_PENDING"
            operation_id = operation["operation_id"]
        return {
            "schema_version": "drive-exchange-bootstrap-status-result-v1",
            "project_id": request["project_id"],
            "topology_state": state,
            "operation_id": operation_id,
            "active_routes": [],
            "role_names": [],
        }

    def enable_role_route(
        self, *, project_id: str, route_name: str, role: str
    ) -> dict:
        if _MANAGED_ROLE_ROUTES.get(route_name) != role:
            raise HubError("ROUTE_ROLE_DENIED")
        with self._connect() as connection:
            role_row = connection.execute(
                "SELECT remote_id FROM project_roles WHERE project_id=? AND role=?",
                (project_id, role),
            ).fetchone()
            standard = connection.execute(
                "SELECT verification_json FROM routes WHERE project_id=? AND route_name='standard' AND enabled=1",
                (project_id,),
            ).fetchone()
            if role_row is None or standard is None:
                raise HubError("TOPOLOGY_UNBOUND")
            verification = json.loads(standard["verification_json"])
            verification["folder_id"] = role_row["remote_id"]
            try:
                connection.execute(
                    "INSERT INTO routes VALUES (?, ?, ?, 1, ?, ?)",
                    (
                        project_id, route_name, role_row["remote_id"],
                        canonical_json_bytes(verification), _utc_now(),
                    ),
                )
            except sqlite3.IntegrityError as error:
                raise HubError("ROUTE_BINDING_CONFLICT") from error
        return self.show_route(project_id, route_name)

    def close_bootstrap(
        self,
        operation_id: str,
        *,
        state: str,
        result: dict,
        error: dict | None,
    ) -> dict:
        if state not in {"AMBIGUOUS", "REJECTED"}:
            raise HubError("BOOTSTRAP_STATE_INVALID")
        terminal = state == "REJECTED"
        with self._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            current = connection.execute(
                "SELECT state, result_json FROM bootstrap_operations WHERE operation_id=?",
                (operation_id,),
            ).fetchone()
            if current is None:
                raise HubError("OPERATION_NOT_FOUND")
            if current["state"] in {"SUCCEEDED", "REJECTED"}:
                if current["result_json"] is None:
                    raise HubError("BOOTSTRAP_STATE_INVALID")
                return json.loads(current["result_json"])
            cursor = connection.execute(
                "UPDATE bootstrap_operations SET state=?, result_json=?, error_json=?, "
                "completed_at=? WHERE operation_id=? AND state=?",
                (
                    state,
                    canonical_json_bytes(result),
                    None if error is None else canonical_json_bytes(error),
                    _utc_now() if terminal else None,
                    operation_id,
                    current["state"],
                ),
            )
            if cursor.rowcount != 1:
                raise HubError("BOOTSTRAP_STATE_INVALID")
        return result

    def activate_bootstrap(
        self,
        *,
        request: dict,
        parent: dict,
        root_id: str,
        roles: list[dict],
        mapping_sha256: str,
        result: dict,
        receipt: dict,
        receipt_sha256: str,
        completed_at: str,
        expected_state: str = "ACTIVATING",
    ) -> dict:
        if expected_state not in {"ACTIVATING", "AMBIGUOUS"}:
            raise HubError("BOOTSTRAP_STATE_INVALID")
        now = completed_at
        receipt_bytes = canonical_json_bytes(receipt)
        result_bytes = canonical_json_bytes(result)
        verification = {
            "schema_version": "drive-exchange-route-verification-v1",
            "provider": "google-drive",
            "folder_id": next(item["remote_id"] for item in roles if item["role"] == "reports"),
            "drive_identity": parent["drive_identity"],
            "verified": True,
            "verified_at": now,
        }
        reports_id = verification["folder_id"]
        try:
            with self._connect() as connection:
                connection.execute("BEGIN IMMEDIATE")
                existing_project = connection.execute(
                    "SELECT project_identity, display_name, managed FROM projects WHERE project_id=?",
                    (request["project_id"],),
                ).fetchone()
                if (
                    existing_project is None
                    or existing_project["project_identity"] != request["project_identity"]
                    or existing_project["display_name"] != request["display_name"]
                    or existing_project["managed"] != 1
                ):
                    raise HubError("PROJECT_REGISTRATION_CONFLICT")
                connection.execute(
                    "INSERT INTO project_topologies VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (
                        request["project_id"], request["project_identity"],
                        request["topology_profile"], request["topology_profile_sha256"],
                        request["config_sha256"], parent["folder_id"], root_id,
                        request["operation_id"], mapping_sha256, now,
                    ),
                )
                for item in roles:
                    connection.execute(
                        "INSERT INTO project_roles VALUES (?, ?, ?, ?, ?, ?)",
                        (request["project_id"], item["ordinal"], item["role"], item["remote_id"], item["name"], item["kind"]),
                    )
                connection.execute(
                    "INSERT INTO routes VALUES (?, 'standard', ?, 1, ?, ?)",
                    (request["project_id"], reports_id, canonical_json_bytes(verification), now),
                )
                connection.execute(
                    "INSERT INTO bootstrap_receipts VALUES (?, ?, ?, ?)",
                    (request["operation_id"], receipt_bytes, len(receipt_bytes), receipt_sha256),
                )
                cursor = connection.execute(
                    "UPDATE bootstrap_operations SET state='SUCCEEDED', result_json=?, "
                    "completed_at=? WHERE operation_id=? AND state=?",
                    (result_bytes, now, request["operation_id"], expected_state),
                )
                if cursor.rowcount != 1:
                    raise HubError("BOOTSTRAP_STATE_INVALID")
        except sqlite3.IntegrityError as error:
            raise HubError("BOOTSTRAP_ACTIVATION_CONFLICT") from error
        return result


class FakeDriveConnector:
    max_items_per_operation: int | None = None

    def __init__(
        self,
        *,
        folders: set[str],
        outcomes: dict[str, dict] | None = None,
        selected_parent: str | None = None,
        selected_parent_drive_id: str | None = None,
        drive_identity: str = "fake-drive:local-test",
        topology_outcomes: dict[str, str] | None = None,
    ) -> None:
        self._folders = set(folders)
        self._outcomes = dict(outcomes or {})
        self._selected_parent = selected_parent
        self._selected_parent_drive_id = selected_parent_drive_id
        self._drive_identity = drive_identity
        self._topology_outcomes = dict(topology_outcomes or {})
        self._topology_method_counts: dict[str, int] = {}
        self._objects: dict[str, dict] = {}
        self._catalog_templates: dict[str, dict] = {}
        self._reserved_counter = 0
        self.call_count = 0
        self.calls: list[dict] = []

    def _topology_call(self, method: str, details: dict | None = None) -> str | None:
        ordinal = self._topology_method_counts.get(method, 0) + 1
        self._topology_method_counts[method] = ordinal
        call = {"method": method, **(details or {})}
        self.calls.append(call)
        outcome = self._topology_outcomes.get(f"{method}:{ordinal}")
        if outcome == "definitive":
            raise ConnectorDefinitiveError(
                {"code": "fakeDefinitive", "message": f"{method} definitively rejected"}
            )
        if outcome == "ambiguous":
            raise ConnectorAmbiguousError(
                {"code": "fakeAmbiguous", "message": f"{method} outcome unknown"}
            )
        return outcome

    @staticmethod
    def _copy(value: dict) -> dict:
        return json.loads(canonical_json_bytes(value))

    def select_parent_folder(self) -> dict:
        outcome = self._topology_call("select_parent_folder")
        if outcome == "malformed":
            return {}
        if self._selected_parent is None or self._selected_parent not in self._folders:
            raise ConnectorDefinitiveError(
                {"code": "parentNotSelected", "message": "no valid parent was selected"}
            )
        result = {
            "folder_id": self._selected_parent,
            "drive_identity": self._drive_identity,
            "mime_type": "application/vnd.google-apps.folder",
            "trashed": False,
            "capabilities": {"canAddChildren": True, "canListChildren": True},
        }
        if self._selected_parent_drive_id is not None:
            result["driveId"] = self._selected_parent_drive_id
        return result

    def list_project_roots(
        self, *, parent_id: str, project_id: str, project_identity: str
    ) -> list[dict]:
        outcome = self._topology_call(
            "list_project_roots",
            {
                "parent_id": parent_id,
                "project_id": project_id,
                "project_identity": project_identity,
            },
        )
        if outcome == "malformed":
            return [{}]
        return [
            self._copy(value)
            for value in self._objects.values()
            if value["parents"] == [parent_id]
            and value["app_properties"].get("project_id") == project_id
            and value["app_properties"].get("project_identity") == project_identity
            and value["app_properties"].get("role") == "project_root"
        ]

    def reserve_folder_ids(self, count: int) -> list[str]:
        outcome = self._topology_call("reserve_folder_ids", {"count": count})
        if outcome == "malformed":
            return []
        if type(count) is not int or count < 1 or count > 100:
            raise ConnectorDefinitiveError(
                {"code": "invalidCount", "message": "invalid reservation count"}
            )
        result = []
        for _ in range(count):
            self._reserved_counter += 1
            result.append(f"fake-folder-{self._reserved_counter:04d}")
        return result

    def _create_object(
        self,
        *,
        remote_id: str,
        parent_id: str,
        name: str,
        mime_type: str,
        app_properties: dict[str, str],
    ) -> dict:
        if remote_id in self._objects or parent_id not in self._folders | set(self._objects):
            raise ConnectorDefinitiveError(
                {"code": "invalidObject", "message": "object identity or parent invalid"}
            )
        value = {
            "id": remote_id,
            "name": name,
            "mime_type": mime_type,
            "parents": [parent_id],
            "trashed": False,
            "app_properties": dict(app_properties),
        }
        self._objects[remote_id] = value
        return self._copy(value)

    def create_folder(
        self,
        *,
        remote_id: str,
        parent_id: str,
        name: str,
        app_properties: dict[str, str],
    ) -> dict:
        outcome = self._topology_call(
            "create_folder", {"remote_id": remote_id, "parent_id": parent_id, "name": name}
        )
        if outcome == "malformed":
            return {}
        created = self._create_object(
            remote_id=remote_id,
            parent_id=parent_id,
            name=name,
            mime_type="application/vnd.google-apps.folder",
            app_properties=app_properties,
        )
        if outcome == "commit_then_ambiguous":
            raise ConnectorAmbiguousError(
                {"code": "fakeAmbiguous", "message": "create_folder response lost"}
            )
        return created

    def create_catalog(
        self,
        *,
        parent_id: str,
        name: str,
        app_properties: dict[str, str],
    ) -> dict:
        outcome = self._topology_call(
            "create_catalog", {"parent_id": parent_id, "name": name}
        )
        if outcome == "malformed":
            return {}
        remote_id = f"fake-sheet-{len(self._objects) + 1:04d}"
        created = self._create_object(
            remote_id=remote_id,
            parent_id=parent_id,
            name=name,
            mime_type="application/vnd.google-apps.spreadsheet",
            app_properties=app_properties,
        )
        if outcome == "commit_then_ambiguous":
            raise ConnectorAmbiguousError(
                {"code": "fakeAmbiguous", "message": "create_catalog response lost"}
            )
        return created

    def apply_catalog_template(self, *, remote_id: str, batch_update: dict) -> dict:
        outcome = self._topology_call("apply_catalog_template", {"remote_id": remote_id})
        if outcome == "malformed":
            return {}
        if remote_id not in self._objects:
            raise ConnectorDefinitiveError(
                {"code": "notFound", "message": "catalog not found"}
            )
        digest = hashlib.sha256(canonical_json_bytes(batch_update)).hexdigest()
        self._catalog_templates[remote_id] = self._copy(batch_update)
        if outcome == "commit_then_ambiguous":
            raise ConnectorAmbiguousError(
                {"code": "fakeAmbiguous", "message": "catalog template response lost"}
            )
        return {"remote_id": remote_id, "template_sha256": digest, "applied": True}

    def inspect_catalog(self, remote_id: str, expected_batch_update: dict) -> dict:
        outcome = self._topology_call("inspect_catalog", {"remote_id": remote_id})
        if outcome == "malformed":
            return {}
        if remote_id not in self._objects:
            raise ConnectorDefinitiveError(
                {"code": "notFound", "message": "catalog not found"}
            )
        template = self._catalog_templates.get(remote_id)
        if template is None:
            return {"remote_id": remote_id, "state": "PRISTINE"}
        if template != expected_batch_update:
            raise ConnectorDefinitiveError(
                {"code": "catalogDrift", "message": "catalog template differs"}
            )
        return {
            "remote_id": remote_id,
            "state": "EXACT_TEMPLATE",
            "template_sha256": hashlib.sha256(
                canonical_json_bytes(template)
            ).hexdigest(),
        }

    def read_catalog(self, remote_id: str, expected_batch_update: dict) -> dict:
        outcome = self._topology_call("read_catalog", {"remote_id": remote_id})
        if outcome == "malformed":
            return {}
        template = self._catalog_templates.get(remote_id)
        if template is None:
            raise ConnectorDefinitiveError(
                {"code": "notFound", "message": "catalog template not found"}
            )
        if template != expected_batch_update:
            raise ConnectorDefinitiveError(
                {"code": "catalogDrift", "message": "catalog template differs"}
            )
        return {
            "remote_id": remote_id,
            "template_sha256": hashlib.sha256(canonical_json_bytes(template)).hexdigest(),
        }

    def get_object(self, remote_id: str, *, expected_drive_identity: str) -> dict:
        outcome = self._topology_call(
            "get_object",
            {"remote_id": remote_id, "expected_drive_identity": expected_drive_identity},
        )
        if expected_drive_identity != self._drive_identity:
            raise ConnectorAmbiguousError(
                {"code": "readOutcomeUnresolved", "message": "recovery drive identity unresolved"}
            )
        if outcome == "malformed":
            return {}
        if remote_id not in self._objects:
            raise ConnectorDefinitiveError(
                {"code": "notFound", "message": "object not found"}
            )
        return self._copy(self._objects[remote_id])

    def list_operation_objects(
        self, *, operation_id: str, expected_drive_identity: str
    ) -> list[dict]:
        outcome = self._topology_call(
            "list_operation_objects",
            {"operation_id": operation_id, "expected_drive_identity": expected_drive_identity},
        )
        if expected_drive_identity != self._drive_identity:
            raise ConnectorAmbiguousError(
                {"code": "readOutcomeUnresolved", "message": "recovery drive identity unresolved"}
            )
        if outcome == "malformed":
            return [{}]
        return [
            self._copy(value)
            for value in self._objects.values()
            if value["app_properties"].get("operation_id") == operation_id
        ]

    def rename_object(self, *, remote_id: str, name: str) -> dict:
        outcome = self._topology_call("rename_object", {"remote_id": remote_id, "name": name})
        if outcome == "malformed":
            return {}
        if remote_id not in self._objects:
            raise ConnectorDefinitiveError(
                {"code": "notFound", "message": "object not found"}
            )
        self._objects[remote_id] = {**self._objects[remote_id], "name": name}
        return self._copy(self._objects[remote_id])

    def human_remove_operation_objects(self, operation_id: str) -> None:
        """Fake-only simulation of an out-of-band Human cleanup."""
        remote_ids = [
            remote_id
            for remote_id, value in self._objects.items()
            if value["app_properties"].get("operation_id") == operation_id
        ]
        for remote_id in remote_ids:
            self._objects.pop(remote_id, None)
            self._catalog_templates.pop(remote_id, None)

    def verify_folder(self, folder_id: str) -> dict:
        if folder_id not in self._folders:
            raise HubError("ROUTE_BINDING_UNVERIFIED")
        return {
            "schema_version": "drive-exchange-route-verification-v1",
            "provider": "fake-drive",
            "folder_id": folder_id,
            "drive_identity": "fake-drive:local-test",
            "verified": True,
            "verified_at": "2026-08-25T00:00:00Z",
        }

    def upload(
        self,
        *,
        folder_id: str,
        expected_drive_identity: str = "fake-drive:local-test",
        source_path: str,
        body: bytes,
        operation_id: str,
    ) -> dict:
        if expected_drive_identity != "fake-drive:local-test":
            raise ConnectorDefinitiveError(
                {
                    "code": "driveIdentityMismatch",
                    "message": "active Drive identity does not match route binding",
                }
            )
        self.call_count += 1
        call = {"folder_id": folder_id, "source_path": source_path}
        self.calls.append(call)
        outcome = self._outcomes.get(source_path)
        if outcome is not None and outcome.get("kind") == "definitive":
            raise ConnectorDefinitiveError(dict(outcome["error"]))
        if outcome is not None and outcome.get("kind") == "ambiguous":
            raise ConnectorAmbiguousError(dict(outcome["error"]))
        digest = hashlib.sha256(
            operation_id.encode("ascii") + b"\x00" + source_path.encode("utf-8") + body
        ).hexdigest()
        result = {
            "remote_file_id": "fake-file-" + digest[:24],
            "revision": "fake-rev-" + digest[24:40],
            "byte_size": len(body),
            "sha256": hashlib.sha256(body).hexdigest(),
        }
        call.update(result)
        return result


class _FrameReader:
    def __init__(self, payload: bytes) -> None:
        self.payload = payload
        self.offset = 0

    def read(self, count: int) -> bytes:
        if count < 0 or self.offset + count > len(self.payload):
            raise HubError("REQUEST_INVALID")
        start = self.offset
        self.offset += count
        return self.payload[start : self.offset]

    def uint32(self) -> int:
        return struct.unpack(">I", self.read(4))[0]

    def uint64(self) -> int:
        return struct.unpack(">Q", self.read(8))[0]


def _parse_request(payload: bytes) -> dict:
    try:
        value = json.loads(payload.decode("utf-8", errors="strict"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise HubError("REQUEST_INVALID") from error
    if not isinstance(value, dict) or set(value) != _REQUEST_KEYS:
        raise HubError("REQUEST_INVALID")
    if canonical_json_bytes(value) != payload:
        raise HubError("REQUEST_INVALID")
    if (
        value["schema_version"] != "drive-exchange-local-request-v1"
        or not isinstance(value["operation_id"], str)
        or _OPERATION_ID.fullmatch(value["operation_id"]) is None
        or not isinstance(value["project_id"], str)
        or _PROJECT_ID.fullmatch(value["project_id"]) is None
        or not isinstance(value["project_identity"], str)
        or not isinstance(value["route_name"], str)
        or _NAME.fullmatch(value["route_name"]) is None
        or value["mode"] not in {"preflight", "submit"}
        or not isinstance(value["manifest_sha256"], str)
        or _DIGEST.fullmatch(value["manifest_sha256"]) is None
        or not isinstance(value["frame_sha256"], str)
        or _DIGEST.fullmatch(value["frame_sha256"]) is None
    ):
        raise HubError("REQUEST_INVALID")
    return value


def _request_schema(payload: bytes) -> str:
    try:
        value = json.loads(payload.decode("utf-8", errors="strict"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise HubError("REQUEST_INVALID") from error
    if not isinstance(value, dict) or not isinstance(value.get("schema_version"), str):
        raise HubError("REQUEST_INVALID")
    return value["schema_version"]


def _parse_bootstrap_request(payload: bytes) -> dict:
    try:
        value = json.loads(payload.decode("utf-8", errors="strict"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise HubError("BOOTSTRAP_REQUEST_INVALID") from error
    try:
        canonical = canonical_json_bytes(value)
    except HubError as error:
        raise HubError("BOOTSTRAP_REQUEST_INVALID") from error
    if (
        not isinstance(value, dict)
        or set(value) != _BOOTSTRAP_REQUEST_KEYS
        or canonical != payload
    ):
        raise HubError("BOOTSTRAP_REQUEST_INVALID")
    operation_id = value["operation_id"]
    if (
        value["schema_version"] != "drive-exchange-bootstrap-request-v1"
        or not isinstance(operation_id, str)
        or _OPERATION_ID.fullmatch(operation_id) is None
        or value["request_id"] != operation_id
        or not isinstance(value["project_id"], str)
        or _PROJECT_ID.fullmatch(value["project_id"]) is None
        or not isinstance(value["project_identity"], str)
        or re.fullmatch(r"project-sha256:[0-9a-f]{64}", value["project_identity"]) is None
        or not isinstance(value["config_sha256"], str)
        or _DIGEST.fullmatch(value["config_sha256"]) is None
        or not _valid_managed_display_name(value["display_name"])
        or value["topology_profile"] != "drive-exchange-managed-project-v1"
        or not isinstance(value["topology_profile_sha256"], str)
        or _DIGEST.fullmatch(value["topology_profile_sha256"]) is None
    ):
        raise HubError("BOOTSTRAP_REQUEST_INVALID")
    return value


def _parse_bootstrap_status_request(payload: bytes) -> dict:
    try:
        value = json.loads(payload.decode("utf-8", errors="strict"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise HubError("BOOTSTRAP_STATUS_REQUEST_INVALID") from error
    if (
        not isinstance(value, dict)
        or set(value) != _BOOTSTRAP_STATUS_REQUEST_KEYS
        or canonical_json_bytes(value) != payload
        or value["schema_version"] != "drive-exchange-bootstrap-status-request-v1"
        or not isinstance(value["project_id"], str)
        or _PROJECT_ID.fullmatch(value["project_id"]) is None
        or not isinstance(value["project_identity"], str)
        or re.fullmatch(r"project-sha256:[0-9a-f]{64}", value["project_identity"]) is None
        or not isinstance(value["config_sha256"], str)
        or _DIGEST.fullmatch(value["config_sha256"]) is None
        or value["topology_profile"] != "drive-exchange-managed-project-v1"
        or not isinstance(value["topology_profile_sha256"], str)
        or _DIGEST.fullmatch(value["topology_profile_sha256"]) is None
    ):
        raise HubError("BOOTSTRAP_STATUS_REQUEST_INVALID")
    return value


def _closed_bootstrap_parent(value: object) -> dict:
    base = {"folder_id", "drive_identity", "mime_type", "trashed", "capabilities"}
    if not isinstance(value, dict) or frozenset(value) not in {frozenset(base), frozenset(base | {"driveId"})}:
        raise HubError("BOOTSTRAP_PARENT_INVALID")
    capabilities = value["capabilities"]
    if (
        not isinstance(value["folder_id"], str)
        or not value["folder_id"]
        or not isinstance(value["drive_identity"], str)
        or not value["drive_identity"]
        or value["mime_type"] != "application/vnd.google-apps.folder"
        or type(value["trashed"]) is not bool
        or value["trashed"] is not False
        or not isinstance(capabilities, dict)
        or set(capabilities) != {"canAddChildren", "canListChildren"}
        or type(capabilities["canAddChildren"]) is not bool
        or capabilities["canAddChildren"] is not True
        or type(capabilities["canListChildren"]) is not bool
        or capabilities["canListChildren"] is not True
    ):
        raise HubError("BOOTSTRAP_PARENT_INVALID")
    if "driveId" in value:
        if not isinstance(value["driveId"], str) or not value["driveId"]:
            raise HubError("BOOTSTRAP_PARENT_INVALID")
        raise HubError("SHARED_DRIVE_UNSUPPORTED")
    return json.loads(canonical_json_bytes(value))


def _closed_bootstrap_object(
    value: object,
    *,
    remote_id: str,
    parent_id: str,
    name: str,
    mime_type: str,
    app_properties: dict[str, str],
) -> dict:
    expected_keys = {"id", "name", "mime_type", "parents", "trashed", "app_properties"}
    if not isinstance(value, dict) or set(value) != expected_keys:
        raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")
    if (
        value["id"] != remote_id
        or value["name"] != name
        or value["mime_type"] != mime_type
        or value["parents"] != [parent_id]
        or type(value["trashed"]) is not bool
        or value["trashed"] is not False
        or value["app_properties"] != app_properties
    ):
        raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")
    return json.loads(canonical_json_bytes(value))


def _validate_source_path(value: object) -> str:
    if (
        not isinstance(value, str)
        or not value
        or unicodedata.normalize("NFC", value) != value
        or value.startswith("/")
        or "\\" in value
        or any(character in value for character in ":*?[]")
    ):
        raise HubError("SOURCE_PATH_DENIED")
    for component in value.split("/"):
        if (
            not component
            or component in {".", ".."}
            or component.endswith((".", " "))
            or any(unicodedata.category(character) == "Cc" for character in component)
            or component.split(".", 1)[0].casefold() in _RESERVED_NAMES
        ):
            raise HubError("SOURCE_PATH_DENIED")
    return value


def _parse_frame(request: dict, frame_bytes: bytes) -> tuple[dict, list[bytes]]:
    if hashlib.sha256(frame_bytes).hexdigest() != request["frame_sha256"]:
        raise HubError("REQUEST_INVALID")
    reader = _FrameReader(frame_bytes)
    if reader.read(len(_FRAME_MAGIC)) != _FRAME_MAGIC:
        raise HubError("REQUEST_INVALID")
    manifest_bytes = reader.read(reader.uint64())
    if hashlib.sha256(manifest_bytes).hexdigest() != request["manifest_sha256"]:
        raise HubError("REQUEST_INVALID")
    try:
        manifest = json.loads(manifest_bytes.decode("utf-8", errors="strict"))
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise HubError("REQUEST_INVALID") from error
    if canonical_json_bytes(manifest) != manifest_bytes:
        raise HubError("REQUEST_INVALID")
    if (
        not isinstance(manifest, dict)
        or set(manifest) != {"schema_version", "project_id", "route", "files"}
        or manifest["schema_version"] != "drive-exchange-manifest-v1"
        or manifest["project_id"] != request["project_id"]
        or not isinstance(manifest["route"], str)
        or _NAME.fullmatch(manifest["route"]) is None
        or not isinstance(manifest["files"], list)
        or not manifest["files"]
    ):
        raise HubError("REQUEST_INVALID")
    if manifest["route"] != request["route_name"]:
        raise HubError("ROUTE_MANIFEST_MISMATCH")
    bodies = []
    seen_paths: set[str] = set()
    ordered_paths: list[str] = []
    for record in manifest["files"]:
        if not isinstance(record, dict) or set(record) != {
            "path",
            "byte_size",
            "sha256",
        }:
            raise HubError("REQUEST_INVALID")
        record_path = _validate_source_path(record["path"])
        if record_path.casefold() in seen_paths:
            raise HubError("SOURCE_PATH_DENIED")
        seen_paths.add(record_path.casefold())
        ordered_paths.append(record_path)
        if (
            type(record["byte_size"]) is not int
            or record["byte_size"] < 0
            or not isinstance(record["sha256"], str)
            or _DIGEST.fullmatch(record["sha256"]) is None
        ):
            raise HubError("REQUEST_INVALID")
        path = reader.read(reader.uint32()).decode("utf-8", errors="strict")
        body = reader.read(reader.uint64())
        if (
            path != record_path
            or len(body) != record["byte_size"]
            or hashlib.sha256(body).hexdigest() != record["sha256"]
        ):
            raise HubError("REQUEST_INVALID")
        bodies.append(body)
    if ordered_paths != sorted(ordered_paths, key=lambda value: value.encode("utf-8")):
        raise HubError("REQUEST_INVALID")
    if reader.offset != len(frame_bytes):
        raise HubError("REQUEST_INVALID")
    return manifest, bodies


class LocalHub:
    protocol = "drive-exchange-local-hub-mvp-v1"

    def __init__(
        self,
        *,
        store: HubStore,
        connector: object,
        topology_profile_path: Path | None = None,
    ) -> None:
        self.store = store
        self.connector = connector
        self.topology_profile_path = (
            None if topology_profile_path is None else Path(topology_profile_path)
        )
        self._writer_lock = threading.Lock()

    def exchange(self, request_bytes: bytes, frame_bytes: bytes) -> dict:
        with self._writer_lock:
            schema = _request_schema(request_bytes)
            if schema == 'drive-exchange-material-recovery-v1':
                from .material_recovery import exchange
                return exchange(self, request_bytes, frame_bytes)
            if schema == "drive-exchange-bootstrap-request-v1":
                if frame_bytes != b"":
                    raise HubError("BOOTSTRAP_REQUEST_INVALID")
                return self._exchange_bootstrap_serialized(request_bytes)
            if schema == "drive-exchange-bootstrap-status-request-v1":
                if frame_bytes != b"":
                    raise HubError("BOOTSTRAP_STATUS_REQUEST_INVALID")
                request = _parse_bootstrap_status_request(request_bytes)
                if self.topology_profile_path is None:
                    raise HubError("TOPOLOGY_PROFILE_UNAVAILABLE")
                from .topology import load_topology_profile

                profile = load_topology_profile(self.topology_profile_path)
                if request["topology_profile_sha256"] != profile.profile_sha256:
                    raise HubError("TOPOLOGY_PROFILE_MISMATCH")
                return self.store.client_topology_status(request)
            return self._exchange_serialized(request_bytes, frame_bytes)

    def _bootstrap_failure(
        self,
        request: dict,
        *,
        error: dict[str, str],
        ambiguous: bool,
    ) -> dict:
        residue = self.store.bootstrap_residue(request["operation_id"])
        if residue:
            ambiguous = True
        state = "BOOTSTRAP_AMBIGUOUS" if ambiguous else "BOOTSTRAP_REJECTED"
        result = {
            "schema_version": "drive-exchange-bootstrap-result-v1",
            "state": state,
            "operation_id": request["operation_id"],
            "request_id": request["request_id"],
            "project_id": request["project_id"],
            "connector_call_count": self.store.bootstrap_snapshot(
                request["operation_id"]
            )["remote_call_count"],
            "error": error,
            "residue": residue,
            "human_cleanup_required": bool(residue),
            "retry_allowed": False,
            "replay_allowed": False,
        }
        return self.store.close_bootstrap(
            request["operation_id"],
            state="AMBIGUOUS" if ambiguous else "REJECTED",
            result=result,
            error=error,
        )

    def _exchange_bootstrap_serialized(self, request_bytes: bytes) -> dict:
        from .topology import catalog_batch_update, load_topology_profile

        request = _parse_bootstrap_request(request_bytes)
        if self.topology_profile_path is None:
            raise HubError("TOPOLOGY_PROFILE_UNAVAILABLE")
        profile = load_topology_profile(self.topology_profile_path)
        if (
            request["topology_profile"] != profile.profile_id
            or request["topology_profile_sha256"] != profile.profile_sha256
        ):
            raise HubError("TOPOLOGY_PROFILE_MISMATCH")
        replayed = self.store.replayed_bootstrap(request["operation_id"], request_bytes)
        if replayed is not None:
            if replayed["result_json"] is not None:
                return json.loads(replayed["result_json"])
            return self._bootstrap_failure(
                request,
                error={
                    "code": "processInterrupted",
                    "message": "issued bootstrap intent requires read-only reconciliation",
                },
                ambiguous=True,
            )
        active = self.store.active_bootstrap_result(request)
        if active is not None:
            return active
        stored = self.store.begin_bootstrap(request, request_bytes)
        if stored is not None:
            raise HubError("BOOTSTRAP_STATE_INVALID")

        mutation_issued = False
        step_ordinal = -1

        def step(
            name: str,
            *,
            mutation: bool,
            expected_state: str,
            state: str,
            intent: dict,
            call,
        ):
            nonlocal step_ordinal, mutation_issued
            step_ordinal += 1
            self.store.bootstrap_record_step_intent(
                operation_id=request["operation_id"],
                step_ordinal=step_ordinal,
                step_name=name,
                mutation=mutation,
                expected_state=expected_state,
                state=state,
                intent=intent,
            )
            if mutation:
                mutation_issued = True
            try:
                value = call()
            except ConnectorDefinitiveError:
                self.store.bootstrap_reject_step(request["operation_id"], step_ordinal)
                raise
            self.store.bootstrap_record_step_result(
                request["operation_id"], step_ordinal, value
            )
            return value

        try:
            parent_value = step(
                "select_parent",
                mutation=False,
                expected_state="SELECTING_PARENT",
                state="SELECTING_PARENT",
                intent={"picker": "single-folder", "scope": "drive.file"},
                call=self.connector.select_parent_folder,
            )
            parent = _closed_bootstrap_parent(parent_value)
            self.store.bootstrap_set_parent(request["operation_id"], parent)

            roots = step(
                "list_project_roots",
                mutation=False,
                expected_state="CREATING_ROOT",
                state="CREATING_ROOT",
                intent={
                    "parent_id": parent["folder_id"],
                    "project_id": request["project_id"],
                    "project_identity": request["project_identity"],
                },
                call=lambda: self.connector.list_project_roots(
                    parent_id=parent["folder_id"], project_id=request["project_id"],
                    project_identity=request["project_identity"],
                ),
            )
            if not isinstance(roots, list) or any(
                not isinstance(item, dict)
                or set(item) != {"id", "name", "mime_type", "parents", "trashed", "app_properties"}
                for item in roots
            ):
                raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")
            if roots:
                return self._bootstrap_failure(
                    request,
                    error={"code": "projectRootConflict", "message": "managed project root already visible"},
                    ambiguous=False,
                )

            reserved = step(
                "reserve_folder_ids",
                mutation=False,
                expected_state="CREATING_ROOT",
                state="CREATING_ROOT",
                intent={"count": 6},
                call=lambda: self.connector.reserve_folder_ids(6),
            )
            if (
                not isinstance(reserved, list)
                or len(reserved) != 6
                or len(set(reserved)) != 6
                or any(not isinstance(item, str) or not item for item in reserved)
            ):
                raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")

            common_properties = {
                "operation_id": request["operation_id"],
                "project_id": request["project_id"],
                "project_identity": request["project_identity"],
                "profile_id": profile.profile_id,
            }
            root_properties = {**common_properties, "role": "project_root"}
            staging_name = ".drive-exchange-staging-" + request["operation_id"][3:15]
            root_intent = {
                "remote_id": reserved[0], "parent_id": parent["folder_id"],
                "name": staging_name, "app_properties": root_properties,
            }
            self.store.bootstrap_record_intent(
                operation_id=request["operation_id"], ordinal=-1,
                role="project_root", name=staging_name, kind="folder",
                parent_role=None, intent=root_intent,
                expected_state="CREATING_ROOT", state="CREATING_ROOT",
            )
            mutation_issued = True
            try:
                root_raw = self.connector.create_folder(**root_intent)
            except ConnectorDefinitiveError:
                self.store.bootstrap_reject_object(request["operation_id"], -1)
                raise
            root = _closed_bootstrap_object(
                root_raw, remote_id=reserved[0], parent_id=parent["folder_id"],
                name=staging_name, mime_type="application/vnd.google-apps.folder",
                app_properties=root_properties,
            )
            self.store.bootstrap_record_object(request["operation_id"], -1, root)
            self.store.bootstrap_transition(
                request["operation_id"],
                expected_state="CREATING_ROOT",
                state="CREATING_FOLDERS",
            )

            role_objects: dict[str, dict] = {}
            folder_items = [item for item in profile.ordered_objects if item.kind == "folder"]
            for item, remote_id in zip(folder_items, reserved[1:], strict=True):
                properties = {**common_properties, "role": item.role}
                intent = {
                    "remote_id": remote_id, "parent_id": root["id"],
                    "name": item.name, "app_properties": properties,
                }
                self.store.bootstrap_record_intent(
                    operation_id=request["operation_id"], ordinal=item.ordinal,
                    role=item.role, name=item.name, kind=item.kind,
                    parent_role="project_root", intent=intent,
                    expected_state="CREATING_FOLDERS", state="CREATING_FOLDERS",
                )
                mutation_issued = True
                try:
                    raw = self.connector.create_folder(**intent)
                except ConnectorDefinitiveError:
                    self.store.bootstrap_reject_object(
                        request["operation_id"], item.ordinal
                    )
                    raise
                closed = _closed_bootstrap_object(
                    raw, remote_id=remote_id, parent_id=root["id"], name=item.name,
                    mime_type="application/vnd.google-apps.folder",
                    app_properties=properties,
                )
                self.store.bootstrap_record_object(request["operation_id"], item.ordinal, closed)
                role_objects[item.role] = closed

            catalog_item = next(item for item in profile.ordered_objects if item.role == "data_catalog")
            catalog_properties = {**common_properties, "role": catalog_item.role}
            catalog_intent = {
                "parent_id": root["id"], "name": catalog_item.name,
                "app_properties": catalog_properties,
            }
            self.store.bootstrap_record_intent(
                operation_id=request["operation_id"], ordinal=catalog_item.ordinal,
                role=catalog_item.role, name=catalog_item.name, kind=catalog_item.kind,
                parent_role="project_root", intent=catalog_intent,
                expected_state="CREATING_FOLDERS", state="CREATING_CATALOG",
            )
            mutation_issued = True
            try:
                catalog_raw = self.connector.create_catalog(**catalog_intent)
            except ConnectorDefinitiveError:
                self.store.bootstrap_reject_object(
                    request["operation_id"], catalog_item.ordinal
                )
                raise
            if not isinstance(catalog_raw, dict) or not isinstance(catalog_raw.get("id"), str):
                raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")
            catalog = _closed_bootstrap_object(
                catalog_raw, remote_id=catalog_raw["id"], parent_id=root["id"],
                name=catalog_item.name, mime_type="application/vnd.google-apps.spreadsheet",
                app_properties=catalog_properties,
            )
            self.store.bootstrap_record_object(request["operation_id"], catalog_item.ordinal, catalog)
            role_objects[catalog_item.role] = catalog

            links = {
                role: "https://drive.google.com/open?id=" + value["id"]
                for role, value in role_objects.items()
            }
            batch = catalog_batch_update(
                profile, project_id=request["project_id"],
                display_name=request["display_name"], role_links=links,
            )
            applied = step(
                "apply_catalog_template", mutation=True,
                expected_state="CREATING_CATALOG", state="CONFIGURING_CATALOG",
                intent={
                    "remote_id": catalog["id"],
                    "batch_sha256": hashlib.sha256(canonical_json_bytes(batch)).hexdigest(),
                    "batch_update": batch,
                },
                call=lambda: self.connector.apply_catalog_template(remote_id=catalog["id"], batch_update=batch),
            )
            expected_template_sha = hashlib.sha256(canonical_json_bytes(batch)).hexdigest()
            if applied != {"remote_id": catalog["id"], "template_sha256": expected_template_sha, "applied": True}:
                raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")

            for verification_index, item in enumerate(profile.ordered_objects):
                expected = role_objects[item.role]
                readback = step(
                    "get_object", mutation=False,
                    expected_state=(
                        "CONFIGURING_CATALOG" if verification_index == 0 else "VERIFYING"
                    ),
                    state="VERIFYING",
                    intent={"remote_id": expected["id"]},
                    call=lambda remote_id=expected["id"]: self.connector.get_object(
                        remote_id, expected_drive_identity=parent["drive_identity"]
                    ),
                )
                _closed_bootstrap_object(
                    readback, remote_id=expected["id"], parent_id=root["id"],
                    name=item.name,
                    mime_type=("application/vnd.google-apps.folder" if item.kind == "folder" else "application/vnd.google-apps.spreadsheet"),
                    app_properties=expected["app_properties"],
                )
            catalog_readback = step(
                "read_catalog", mutation=False,
                expected_state="VERIFYING", state="VERIFYING",
                intent={"remote_id": catalog["id"]},
                call=lambda: self.connector.read_catalog(catalog["id"], batch),
            )
            if catalog_readback != {"remote_id": catalog["id"], "template_sha256": expected_template_sha}:
                raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")

            renamed = step(
                "rename_root", mutation=True,
                expected_state="VERIFYING", state="VERIFYING",
                intent={"remote_id": root["id"], "name": request["display_name"]},
                call=lambda: self.connector.rename_object(remote_id=root["id"], name=request["display_name"]),
            )
            _closed_bootstrap_object(
                renamed, remote_id=root["id"], parent_id=parent["folder_id"],
                name=request["display_name"], mime_type="application/vnd.google-apps.folder",
                app_properties=root_properties,
            )
            final_root = step(
                "get_renamed_root", mutation=False,
                expected_state="VERIFYING", state="ACTIVATING",
                intent={"remote_id": root["id"]},
                call=lambda: self.connector.get_object(
                    root["id"], expected_drive_identity=parent["drive_identity"]
                ),
            )
            _closed_bootstrap_object(
                final_root, remote_id=root["id"], parent_id=parent["folder_id"],
                name=request["display_name"], mime_type="application/vnd.google-apps.folder",
                app_properties=root_properties,
            )

            roles = [
                {"ordinal": item.ordinal, "role": item.role, "name": item.name,
                 "kind": item.kind, "remote_id": role_objects[item.role]["id"]}
                for item in profile.ordered_objects
            ]
            mapping_sha256 = hashlib.sha256(canonical_json_bytes(roles)).hexdigest()
            completed_at = _utc_now()
            created_objects = [
                {
                    "ordinal": -1,
                    "role": "project_root",
                    "name": request["display_name"],
                    "kind": "folder",
                    "parent_role": None,
                    "remote_id": root["id"],
                },
                *[
                    {
                        "ordinal": item["ordinal"],
                        "role": item["role"],
                        "name": item["name"],
                        "kind": item["kind"],
                        "parent_role": "project_root",
                        "remote_id": item["remote_id"],
                    }
                    for item in roles
                ],
            ]
            receipt = {
                "schema_version": "drive-exchange-bootstrap-receipt-v1",
                "operation_id": request["operation_id"],
                "request_id": request["request_id"],
                "request_sha256": hashlib.sha256(request_bytes).hexdigest(),
                "project_id": request["project_id"],
                "project_identity": request["project_identity"],
                "config_sha256": request["config_sha256"],
                "display_name": request["display_name"],
                "topology_profile": profile.profile_id,
                "topology_profile_sha256": profile.profile_sha256,
                "catalog_template_sha256": expected_template_sha,
                "drive_identity": parent["drive_identity"],
                "parent_folder_id": parent["folder_id"],
                "project_root_id": root["id"],
                "created_objects": created_objects,
                "roles": roles,
                "mapping_sha256": mapping_sha256,
                "enabled_route": {"name": "standard", "role": "reports"},
                "completed_at": completed_at,
            }
            receipt_sha256 = hashlib.sha256(canonical_json_bytes(receipt)).hexdigest()
            result = {
                "schema_version": "drive-exchange-bootstrap-result-v1",
                "state": "BOOTSTRAPPED",
                "operation_id": request["operation_id"],
                "request_id": request["request_id"],
                "project_id": request["project_id"],
                "drive_identity": parent["drive_identity"],
                "parent_folder_id": parent["folder_id"],
                "project_root_id": root["id"],
                "roles": roles,
                "mapping_sha256": mapping_sha256,
                "connector_call_count": self.store.bootstrap_snapshot(request["operation_id"])["remote_call_count"],
                "residue": [],
                "human_cleanup_required": False,
                "retry_allowed": False,
                "replay_allowed": False,
                "receipt": receipt,
                "receipt_sha256": receipt_sha256,
            }
            return self.store.activate_bootstrap(
                request=request, parent=parent, root_id=root["id"], roles=roles,
                mapping_sha256=mapping_sha256, result=result, receipt=receipt,
                receipt_sha256=receipt_sha256, completed_at=completed_at,
            )
        except ConnectorDefinitiveError as error:
            return self._bootstrap_failure(
                request,
                error=_closed_connector_error(error.error),
                ambiguous=False,
            )
        except ConnectorAmbiguousError as error:
            return self._bootstrap_failure(
                request,
                error=_closed_connector_error(error.error),
                ambiguous=True,
            )
        except HubError as error:
            return self._bootstrap_failure(
                request,
                error={"code": error.code, "message": "bootstrap validation failed"},
                ambiguous=mutation_issued,
            )
        except Exception:
            return self._bootstrap_failure(
                request,
                error={"code": "providerOutcomeUnresolved", "message": "bootstrap provider outcome unresolved"},
                ambiguous=True,
            )

    def resume_bootstrap(self, operation_id: str) -> dict:
        from .topology import load_topology_profile

        context = self.store.bootstrap_resume_context(operation_id)
        snapshot = context["operation"]
        try:
            request_bytes = bytes(snapshot["request_json"])
            request = _parse_bootstrap_request(request_bytes)
            parent = _closed_bootstrap_parent(json.loads(snapshot["parent_json"]))
            if self.topology_profile_path is None:
                raise HubError("TOPOLOGY_PROFILE_UNAVAILABLE")
            profile = load_topology_profile(self.topology_profile_path)
            if (
                request["topology_profile"] != profile.profile_id
                or request["topology_profile_sha256"] != profile.profile_sha256
            ):
                raise HubError("TOPOLOGY_PROFILE_MISMATCH")
            rows = context["objects"]
            expected_layout = [
                (-1, "project_root", "folder"),
                *[
                    (item.ordinal, item.role, item.kind)
                    for item in profile.ordered_objects
                ],
            ]
            if [
                (row["ordinal"], row["role"], row["kind"])
                for row in rows
            ] != expected_layout:
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
            row_by_role = {row["role"]: row for row in rows}
            root_row = row_by_role["project_root"]
            catalog_row = row_by_role["data_catalog"]
            apply_step = context["apply_step"]
            apply_intent = json.loads(apply_step["intent_json"])
            if (
                not isinstance(apply_intent, dict)
                or set(apply_intent)
                != {"remote_id", "batch_sha256", "batch_update"}
                or apply_intent["remote_id"] != catalog_row["remote_id"]
                or not isinstance(apply_intent["batch_update"], dict)
            ):
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
            expected_batch = apply_intent["batch_update"]
            expected_template_sha = hashlib.sha256(
                canonical_json_bytes(expected_batch)
            ).hexdigest()
            if apply_intent["batch_sha256"] != expected_template_sha:
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
            catalog_confirmed = apply_step["state"] == "CONFIRMED"
            if catalog_confirmed and json.loads(apply_step["result_json"]) != {
                "remote_id": catalog_row["remote_id"],
                "template_sha256": expected_template_sha,
                "applied": True,
            }:
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
        except HubError:
            raise
        except Exception as error:
            raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED") from error

        step_ordinal = context["next_step_ordinal"] - 1
        recovery_step_names: list[str] = []

        def recovery_read(name: str, *, intent: dict, call):
            nonlocal step_ordinal
            step_ordinal += 1
            self.store.bootstrap_record_step_intent(
                operation_id=operation_id,
                step_ordinal=step_ordinal,
                step_name=name,
                mutation=False,
                expected_state="AMBIGUOUS",
                state="AMBIGUOUS",
                intent=intent,
            )
            recovery_step_names.append(name)
            try:
                value = call()
            except ConnectorDefinitiveError as error:
                self.store.bootstrap_reject_step(operation_id, step_ordinal)
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED") from error
            except HubError as error:
                self.store.bootstrap_reject_step(operation_id, step_ordinal)
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED") from error
            self.store.bootstrap_record_step_result(
                operation_id, step_ordinal, value
            )
            return value

        try:
            listed = recovery_read(
                "resume_list_operation_objects",
                intent={
                    "operation_id": operation_id,
                    "expected_drive_identity": parent["drive_identity"],
                },
                call=lambda: self.connector.list_operation_objects(
                    operation_id=operation_id,
                    expected_drive_identity=parent["drive_identity"],
                ),
            )
            if not isinstance(listed, list) or len(listed) != 7:
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
            listed_by_id: dict[str, dict] = {}
            for item in listed:
                if (
                    not isinstance(item, dict)
                    or set(item)
                    != {
                        "id", "name", "mime_type", "parents", "trashed",
                        "app_properties",
                    }
                    or not isinstance(item["id"], str)
                    or not item["id"]
                    or item["id"] in listed_by_id
                    or not isinstance(item["app_properties"], dict)
                    or item["app_properties"].get("operation_id") != operation_id
                ):
                    raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
                listed_by_id[item["id"]] = item
            if set(listed_by_id) != {row["remote_id"] for row in rows}:
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")

            for row in rows:
                intent = json.loads(row["intent_json"])
                if (
                    not isinstance(intent, dict)
                    or not isinstance(intent.get("parent_id"), str)
                    or not isinstance(intent.get("app_properties"), dict)
                ):
                    raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
                remote = recovery_read(
                    "resume_get_" + row["role"],
                    intent={
                        "remote_id": row["remote_id"],
                        "expected_drive_identity": parent["drive_identity"],
                    },
                    call=lambda remote_id=row["remote_id"]: self.connector.get_object(
                        remote_id,
                        expected_drive_identity=parent["drive_identity"],
                    ),
                )
                closed = _closed_bootstrap_object(
                    remote,
                    remote_id=row["remote_id"],
                    parent_id=intent["parent_id"],
                    name=row["name"],
                    mime_type=(
                        "application/vnd.google-apps.folder"
                        if row["kind"] == "folder"
                        else "application/vnd.google-apps.spreadsheet"
                    ),
                    app_properties=intent["app_properties"],
                )
                if listed_by_id[row["remote_id"]] != closed:
                    raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")

            inspected = recovery_read(
                "resume_inspect_catalog",
                intent={
                    "remote_id": catalog_row["remote_id"],
                    "expected_template_sha256": expected_template_sha,
                },
                call=lambda: self.connector.inspect_catalog(
                    catalog_row["remote_id"], expected_batch
                ),
            )
            if inspected not in (
                {"remote_id": catalog_row["remote_id"], "state": "PRISTINE"},
                {
                    "remote_id": catalog_row["remote_id"],
                    "state": "EXACT_TEMPLATE",
                    "template_sha256": expected_template_sha,
                },
            ):
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
            if catalog_confirmed and inspected["state"] != "EXACT_TEMPLATE":
                raise HubError("BOOTSTRAP_RESUME_NOT_ALLOWED")
        except ConnectorAmbiguousError as error:
            return self._bootstrap_failure(
                request,
                error=_closed_connector_error(error.error),
                ambiguous=True,
            )
        except HubError:
            raise
        except Exception:
            return self._bootstrap_failure(
                request,
                error={
                    "code": "providerOutcomeUnresolved",
                    "message": "bootstrap recovery read outcome unresolved",
                },
                ambiguous=True,
            )

        mutation_issued = False

        def continuation_step(
            name: str,
            *,
            mutation: bool,
            expected_state: str,
            state: str,
            intent: dict,
            call,
        ):
            nonlocal step_ordinal, mutation_issued
            step_ordinal += 1
            self.store.bootstrap_record_step_intent(
                operation_id=operation_id,
                step_ordinal=step_ordinal,
                step_name=name,
                mutation=mutation,
                expected_state=expected_state,
                state=state,
                intent=intent,
            )
            if mutation:
                mutation_issued = True
            try:
                value = call()
            except ConnectorDefinitiveError:
                self.store.bootstrap_reject_step(operation_id, step_ordinal)
                raise
            self.store.bootstrap_record_step_result(operation_id, step_ordinal, value)
            return value

        try:
            applied_result = {
                "remote_id": catalog_row["remote_id"],
                "template_sha256": expected_template_sha,
                "applied": True,
            }
            recovery_names = tuple(recovery_step_names)
            if catalog_confirmed:
                self.store.bootstrap_continue_confirmed_catalog(
                    operation_id,
                    original_context=context,
                    expected_recovery_steps=recovery_names,
                )
            elif inspected["state"] == "PRISTINE":
                apply_ordinal = self.store.bootstrap_reissue_rejected_step(
                    operation_id,
                    step_name="apply_catalog_template",
                    expected_intent=apply_intent,
                    state="CONFIGURING_CATALOG",
                    expected_recovery_steps=recovery_names,
                )
                mutation_issued = True
                try:
                    applied = self.connector.apply_catalog_template(
                        remote_id=catalog_row["remote_id"],
                        batch_update=expected_batch,
                    )
                except ConnectorDefinitiveError:
                    self.store.bootstrap_reject_step(operation_id, apply_ordinal)
                    raise
                self.store.bootstrap_record_step_result(
                    operation_id, apply_ordinal, applied
                )
                if applied != applied_result:
                    raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")
            else:
                self.store.bootstrap_confirm_rejected_step_by_readback(
                    operation_id,
                    step_name="apply_catalog_template",
                    expected_intent=apply_intent,
                    result=applied_result,
                    state="CONFIGURING_CATALOG",
                    expected_recovery_steps=recovery_names,
                )

            for index, item in enumerate(profile.ordered_objects):
                row = row_by_role[item.role]
                intent = json.loads(row["intent_json"])
                readback = continuation_step(
                    "resume_verify_" + item.role,
                    mutation=False,
                    expected_state=(
                        "CONFIGURING_CATALOG" if index == 0 else "VERIFYING"
                    ),
                    state="VERIFYING",
                    intent={"remote_id": row["remote_id"]},
                    call=lambda remote_id=row["remote_id"]: self.connector.get_object(
                        remote_id,
                        expected_drive_identity=parent["drive_identity"],
                    ),
                )
                _closed_bootstrap_object(
                    readback,
                    remote_id=row["remote_id"],
                    parent_id=root_row["remote_id"],
                    name=item.name,
                    mime_type=(
                        "application/vnd.google-apps.folder"
                        if item.kind == "folder"
                        else "application/vnd.google-apps.spreadsheet"
                    ),
                    app_properties=intent["app_properties"],
                )

            catalog_readback = continuation_step(
                "resume_read_catalog",
                mutation=False,
                expected_state="VERIFYING",
                state="VERIFYING",
                intent={
                    "remote_id": catalog_row["remote_id"],
                    "expected_template_sha256": expected_template_sha,
                },
                call=lambda: self.connector.read_catalog(
                    catalog_row["remote_id"], expected_batch
                ),
            )
            if catalog_readback != {
                "remote_id": catalog_row["remote_id"],
                "template_sha256": expected_template_sha,
            }:
                raise HubError("BOOTSTRAP_PROVIDER_RESULT_INVALID")

            root_intent = json.loads(root_row["intent_json"])
            renamed = continuation_step(
                "rename_root",
                mutation=True,
                expected_state="VERIFYING",
                state="VERIFYING",
                intent={
                    "remote_id": root_row["remote_id"],
                    "name": request["display_name"],
                },
                call=lambda: self.connector.rename_object(
                    remote_id=root_row["remote_id"],
                    name=request["display_name"],
                ),
            )
            root = _closed_bootstrap_object(
                renamed,
                remote_id=root_row["remote_id"],
                parent_id=parent["folder_id"],
                name=request["display_name"],
                mime_type="application/vnd.google-apps.folder",
                app_properties=root_intent["app_properties"],
            )
            final_root = continuation_step(
                "get_renamed_root",
                mutation=False,
                expected_state="VERIFYING",
                state="ACTIVATING",
                intent={"remote_id": root["id"]},
                call=lambda: self.connector.get_object(
                    root["id"], expected_drive_identity=parent["drive_identity"]
                ),
            )
            _closed_bootstrap_object(
                final_root,
                remote_id=root["id"],
                parent_id=parent["folder_id"],
                name=request["display_name"],
                mime_type="application/vnd.google-apps.folder",
                app_properties=root_intent["app_properties"],
            )

            roles = [
                {
                    "ordinal": item.ordinal,
                    "role": item.role,
                    "name": item.name,
                    "kind": item.kind,
                    "remote_id": row_by_role[item.role]["remote_id"],
                }
                for item in profile.ordered_objects
            ]
            mapping_sha256 = hashlib.sha256(
                canonical_json_bytes(roles)
            ).hexdigest()
            completed_at = _utc_now()
            created_objects = [
                {
                    "ordinal": -1,
                    "role": "project_root",
                    "name": request["display_name"],
                    "kind": "folder",
                    "parent_role": None,
                    "remote_id": root["id"],
                },
                *[
                    {
                        "ordinal": item["ordinal"],
                        "role": item["role"],
                        "name": item["name"],
                        "kind": item["kind"],
                        "parent_role": "project_root",
                        "remote_id": item["remote_id"],
                    }
                    for item in roles
                ],
            ]
            receipt = {
                "schema_version": "drive-exchange-bootstrap-receipt-v1",
                "operation_id": request["operation_id"],
                "request_id": request["request_id"],
                "request_sha256": snapshot["request_sha256"],
                "project_id": request["project_id"],
                "project_identity": request["project_identity"],
                "config_sha256": request["config_sha256"],
                "display_name": request["display_name"],
                "topology_profile": profile.profile_id,
                "topology_profile_sha256": profile.profile_sha256,
                "catalog_template_sha256": expected_template_sha,
                "drive_identity": parent["drive_identity"],
                "parent_folder_id": parent["folder_id"],
                "project_root_id": root["id"],
                "created_objects": created_objects,
                "roles": roles,
                "mapping_sha256": mapping_sha256,
                "enabled_route": {"name": "standard", "role": "reports"},
                "completed_at": completed_at,
            }
            receipt_sha256 = hashlib.sha256(
                canonical_json_bytes(receipt)
            ).hexdigest()
            result = {
                "schema_version": "drive-exchange-bootstrap-result-v1",
                "state": "BOOTSTRAPPED",
                "operation_id": request["operation_id"],
                "request_id": request["request_id"],
                "project_id": request["project_id"],
                "drive_identity": parent["drive_identity"],
                "parent_folder_id": parent["folder_id"],
                "project_root_id": root["id"],
                "roles": roles,
                "mapping_sha256": mapping_sha256,
                "connector_call_count": self.store.bootstrap_snapshot(
                    operation_id
                )["remote_call_count"],
                "residue": [],
                "human_cleanup_required": False,
                "retry_allowed": False,
                "replay_allowed": False,
                "receipt": receipt,
                "receipt_sha256": receipt_sha256,
            }
            return self.store.activate_bootstrap(
                request=request,
                parent=parent,
                root_id=root["id"],
                roles=roles,
                mapping_sha256=mapping_sha256,
                result=result,
                receipt=receipt,
                receipt_sha256=receipt_sha256,
                completed_at=completed_at,
            )
        except ConnectorDefinitiveError as error:
            return self._bootstrap_failure(
                request,
                error=_closed_connector_error(error.error),
                ambiguous=False,
            )
        except ConnectorAmbiguousError as error:
            return self._bootstrap_failure(
                request,
                error=_closed_connector_error(error.error),
                ambiguous=True,
            )
        except HubError as error:
            return self._bootstrap_failure(
                request,
                error={
                    "code": error.code,
                    "message": "bootstrap recovery validation failed",
                },
                ambiguous=mutation_issued,
            )
        except Exception:
            return self._bootstrap_failure(
                request,
                error={
                    "code": "providerOutcomeUnresolved",
                    "message": "bootstrap recovery provider outcome unresolved",
                },
                ambiguous=True,
            )

    def reconcile_bootstrap(self, operation_id: str) -> dict:
        snapshot = self.store.bootstrap_snapshot(operation_id)
        if snapshot["state"] != "AMBIGUOUS":
            raise HubError("BOOTSTRAP_RECONCILIATION_NOT_ALLOWED")
        request = json.loads(snapshot["request_json"])
        rows = self.store.bootstrap_object_rows(operation_id)
        if not rows:
            return json.loads(snapshot["result_json"])
        try:
            from .topology import load_topology_profile

            if self.topology_profile_path is None or snapshot["parent_json"] is None:
                return json.loads(snapshot["result_json"])
            profile = load_topology_profile(self.topology_profile_path)
            parent = json.loads(snapshot["parent_json"])
        except Exception:
            return json.loads(snapshot["result_json"])

        row_by_role = {row["role"]: row for row in rows}
        root_row = row_by_role.get("project_root")
        if root_row is None:
            return json.loads(snapshot["result_json"])

        try:
            listed_for_operation = self.connector.list_operation_objects(
                operation_id=operation_id,
                expected_drive_identity=parent["drive_identity"],
            )
        except Exception:
            return json.loads(snapshot["result_json"])
        if not isinstance(listed_for_operation, list):
            return json.loads(snapshot["result_json"])
        try:
            root_names = {root_row["name"]}
            try:
                rename_intent = self.store.bootstrap_step_intent(
                    operation_id, "rename_root"
                )
            except HubError:
                rename_intent = None
            if isinstance(rename_intent, dict) and isinstance(rename_intent.get("name"), str):
                root_names.add(rename_intent["name"])

            candidates_by_ordinal: dict[int, list[dict]] = {}
            for item in listed_for_operation:
                if (
                    not isinstance(item, dict)
                    or set(item)
                    != {"id", "name", "mime_type", "parents", "trashed", "app_properties"}
                    or not isinstance(item["id"], str)
                    or not item["id"]
                    or not isinstance(item["app_properties"], dict)
                    or item["app_properties"].get("operation_id") != operation_id
                ):
                    return json.loads(snapshot["result_json"])
            for row in rows:
                intent = json.loads(row["intent_json"])
                mime_type = (
                    "application/vnd.google-apps.folder"
                    if row["kind"] == "folder"
                    else "application/vnd.google-apps.spreadsheet"
                )
                allowed_names = root_names if row["role"] == "project_root" else {row["name"]}
                candidates_by_ordinal[row["ordinal"]] = [
                    item
                    for item in listed_for_operation
                    if item["name"] in allowed_names
                    and item["mime_type"] == mime_type
                    and item["parents"] == [intent["parent_id"]]
                    and item["trashed"] is False
                    and item["app_properties"] == intent["app_properties"]
                    and (
                        row["remote_id"] is None
                        or item["id"] == row["remote_id"]
                    )
                ]
            matched_ids = [
                item["id"]
                for candidates in candidates_by_ordinal.values()
                for item in candidates
            ]
        except (KeyError, TypeError, ValueError):
            return json.loads(snapshot["result_json"])
        if (
            any(len(candidates) > 1 for candidates in candidates_by_ordinal.values())
            or len(matched_ids) != len(set(matched_ids))
            or len(matched_ids) != len(listed_for_operation)
        ):
            return json.loads(snapshot["result_json"])
        reconciled_objects: list[dict] = []
        for row in rows:
            candidates = candidates_by_ordinal[row["ordinal"]]
            if row["remote_id"] is None and len(candidates) == 1:
                reconciled_objects.append(
                    {"ordinal": row["ordinal"], "remote": candidates[0]}
                )
        resolved_by_ordinal = {
            item["ordinal"]: item["remote"]["id"] for item in reconciled_objects
        }
        rows = [
            {**row, "remote_id": resolved_by_ordinal.get(row["ordinal"], row["remote_id"])}
            for row in rows
        ]
        row_by_role = {row["role"]: row for row in rows}
        root_row = row_by_role["project_root"]

        present_by_ordinal: dict[int, dict] = {}
        absent = 0
        for row in rows:
            if row["remote_id"] is None:
                absent += 1
                continue
            remote_id = row["remote_id"]
            if not isinstance(remote_id, str):
                return json.loads(snapshot["result_json"])
            try:
                remote = self.connector.get_object(
                    remote_id, expected_drive_identity=parent["drive_identity"]
                )
            except ConnectorDefinitiveError as error:
                closed = _closed_connector_error(error.error)
                if closed["code"] != "notFound":
                    return json.loads(snapshot["result_json"])
                absent += 1
                continue
            except Exception:
                return json.loads(snapshot["result_json"])
            if not isinstance(remote, dict) or remote.get("id") != remote_id:
                return json.loads(snapshot["result_json"])
            if remote_id not in matched_ids:
                return json.loads(snapshot["result_json"])
            present_by_ordinal[row["ordinal"]] = remote
        if reconciled_objects:
            self.store.bootstrap_confirm_reconciled_objects(
                operation_id, reconciled_objects
            )
            rows = self.store.bootstrap_object_rows(operation_id)
            row_by_role = {row["role"]: row for row in rows}
        if (
            absent == len(rows)
            and not present_by_ordinal
            and not listed_for_operation
        ):
            result = {
                "schema_version": "drive-exchange-bootstrap-result-v1",
                "state": "BOOTSTRAP_REJECTED",
                "operation_id": request["operation_id"],
                "request_id": request["request_id"],
                "project_id": request["project_id"],
                "connector_call_count": snapshot["remote_call_count"],
                "error": {
                    "code": "humanCleanupConfirmed",
                    "message": "all operation-created objects are absent",
                },
                "residue": [],
                "human_cleanup_required": False,
                "retry_allowed": False,
                "replay_allowed": False,
            }
            return self.store.close_bootstrap(
                operation_id, state="REJECTED", result=result, error=result["error"]
            )
        if absent == 0 and len(rows) == 7 and len(present_by_ordinal) == 7:
            try:
                catalog_row = row_by_role["data_catalog"]
                catalog_id = catalog_row["remote_id"]
                catalog_intent = self.store.bootstrap_step_intent(
                    operation_id, "apply_catalog_template"
                )
                expected_batch = catalog_intent.get("batch_update")
                if not isinstance(catalog_id, str) or not isinstance(expected_batch, dict):
                    return json.loads(snapshot["result_json"])
                expected_template_sha = hashlib.sha256(
                    canonical_json_bytes(expected_batch)
                ).hexdigest()
                catalog = self.connector.read_catalog(catalog_id, expected_batch)
                if catalog != {
                    "remote_id": catalog_id,
                    "template_sha256": expected_template_sha,
                }:
                    return json.loads(snapshot["result_json"])
                try:
                    applied = self.store.bootstrap_step_result(
                        operation_id, "apply_catalog_template"
                    )
                except HubError:
                    applied = {
                        "remote_id": catalog_id,
                        "template_sha256": expected_template_sha,
                        "applied": True,
                    }
                    self.store.bootstrap_confirm_reconciled_step(
                        operation_id, "apply_catalog_template", applied
                    )
                if applied != {
                    "remote_id": catalog_id,
                    "template_sha256": expected_template_sha,
                    "applied": True,
                }:
                    return json.loads(snapshot["result_json"])
                root_row = row_by_role["project_root"]
                root_intent = json.loads(root_row["intent_json"])
                root = _closed_bootstrap_object(
                    present_by_ordinal[root_row["ordinal"]],
                    remote_id=root_row["remote_id"],
                    parent_id=parent["folder_id"],
                    name=request["display_name"],
                    mime_type="application/vnd.google-apps.folder",
                    app_properties=root_intent["app_properties"],
                )
                roles: list[dict] = []
                for item in profile.ordered_objects:
                    row = row_by_role[item.role]
                    intent = json.loads(row["intent_json"])
                    _closed_bootstrap_object(
                        present_by_ordinal[row["ordinal"]],
                        remote_id=row["remote_id"],
                        parent_id=root["id"],
                        name=item.name,
                        mime_type=(
                            "application/vnd.google-apps.folder"
                            if item.kind == "folder"
                            else "application/vnd.google-apps.spreadsheet"
                        ),
                        app_properties=intent["app_properties"],
                    )
                    roles.append(
                        {"ordinal": item.ordinal, "role": item.role, "name": item.name,
                         "kind": item.kind, "remote_id": row["remote_id"]}
                    )
                if sorted(matched_ids) != sorted(
                    [root["id"], *(item["remote_id"] for item in roles)]
                ):
                    return json.loads(snapshot["result_json"])
                mapping_sha256 = hashlib.sha256(canonical_json_bytes(roles)).hexdigest()
                completed_at = _utc_now()
                created_objects = [
                    {
                        "ordinal": -1,
                        "role": "project_root",
                        "name": request["display_name"],
                        "kind": "folder",
                        "parent_role": None,
                        "remote_id": root["id"],
                    },
                    *[
                        {
                            "ordinal": item["ordinal"],
                            "role": item["role"],
                            "name": item["name"],
                            "kind": item["kind"],
                            "parent_role": "project_root",
                            "remote_id": item["remote_id"],
                        }
                        for item in roles
                    ],
                ]
                receipt = {
                    "schema_version": "drive-exchange-bootstrap-receipt-v1",
                    "operation_id": request["operation_id"],
                    "request_id": request["request_id"],
                    "request_sha256": snapshot["request_sha256"],
                    "project_id": request["project_id"],
                    "project_identity": request["project_identity"],
                    "config_sha256": request["config_sha256"],
                    "display_name": request["display_name"],
                    "topology_profile": profile.profile_id,
                    "topology_profile_sha256": profile.profile_sha256,
                    "catalog_template_sha256": expected_template_sha,
                    "drive_identity": parent["drive_identity"],
                    "parent_folder_id": parent["folder_id"],
                    "project_root_id": root["id"],
                    "created_objects": created_objects,
                    "roles": roles,
                    "mapping_sha256": mapping_sha256,
                    "enabled_route": {"name": "standard", "role": "reports"},
                    "completed_at": completed_at,
                }
                receipt_sha256 = hashlib.sha256(canonical_json_bytes(receipt)).hexdigest()
                result = {
                    "schema_version": "drive-exchange-bootstrap-result-v1",
                    "state": "BOOTSTRAPPED",
                    "operation_id": request["operation_id"],
                    "request_id": request["request_id"],
                    "project_id": request["project_id"],
                    "drive_identity": parent["drive_identity"],
                    "parent_folder_id": parent["folder_id"],
                    "project_root_id": root["id"],
                    "roles": roles,
                    "mapping_sha256": mapping_sha256,
                    "connector_call_count": snapshot["remote_call_count"],
                    "residue": [],
                    "human_cleanup_required": False,
                    "retry_allowed": False,
                    "replay_allowed": False,
                    "receipt": receipt,
                    "receipt_sha256": receipt_sha256,
                }
                return self.store.activate_bootstrap(
                    request=request, parent=parent, root_id=root["id"], roles=roles,
                    mapping_sha256=mapping_sha256, result=result, receipt=receipt,
                    receipt_sha256=receipt_sha256, completed_at=completed_at,
                    expected_state="AMBIGUOUS",
                )
            except Exception:
                return json.loads(snapshot["result_json"])
        error = json.loads(snapshot["error_json"])
        return self._bootstrap_failure(request, error=error, ambiguous=True)

    def _close_issued_attempt(
        self,
        *,
        request: dict,
        request_id: str,
        route: dict,
        drive_identity: str,
        item_index: int,
        state: str,
        error: dict[str, str],
    ) -> dict:
        result = {
            "schema_version": "drive-exchange-local-hub-result-v1",
            "state": state,
            "mode": request["mode"],
            "operation_id": request["operation_id"],
            "request_id": request_id,
            "project_id": request["project_id"],
            "route_name": request["route_name"],
            "destination_folder_id": route["folder_id"],
            "drive_identity": drive_identity,
            "connector_call_count": item_index + 1,
            "error": error,
            "retry_allowed": False,
            "replay_allowed": False,
        }
        result_bytes = canonical_json_bytes(result)
        error_bytes = canonical_json_bytes(error)
        with self.store._connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            operation = connection.execute(
                "UPDATE operations SET state=?, result_json=?, error_json=?, "
                "completed_at=? WHERE operation_id=? AND state='DISPATCHING'",
                (
                    state,
                    result_bytes,
                    error_bytes,
                    _utc_now(),
                    request["operation_id"],
                ),
            )
            item = connection.execute(
                "UPDATE operation_items SET state=?, error_json=? "
                "WHERE operation_id=? AND item_index=? AND state='DISPATCHING'",
                (state, error_bytes, request["operation_id"], item_index),
            )
            if operation.rowcount != 1 or item.rowcount != 1:
                raise HubError("OPERATION_STATE_INVALID")
        return result

    def _close_unresolved_issued_attempt(
        self,
        *,
        request: dict,
        request_id: str,
        route: dict,
        drive_identity: str,
        item_index: int,
    ) -> dict:
        return self._close_issued_attempt(
            request=request,
            request_id=request_id,
            route=route,
            drive_identity=drive_identity,
            item_index=item_index,
            state="AMBIGUOUS",
            error={
                "code": "connectorOutcomeUnresolved",
                "message": "connector outcome could not be closed definitively",
            },
        )

    def _exchange_serialized(
        self, request_bytes: bytes, frame_bytes: bytes
    ) -> dict:
        request = _parse_request(request_bytes)
        request_sha256 = hashlib.sha256(request_bytes + b"\x00" + frame_bytes).hexdigest()
        request_id = "req_" + request_sha256[:32]
        stored = self.store.stored_operation(
            request["operation_id"], request_sha256
        )
        if stored is not None:
            if stored["result_json"] is not None:
                return json.loads(stored["result_json"])
            error = {
                "code": "processInterrupted",
                "message": "dispatch outcome unknown after Hub restart",
            }
            recovery_route = self.store.route_for_recovery(
                request["project_id"], request["route_name"]
            )
            recovery = {
                "schema_version": "drive-exchange-local-hub-result-v1",
                "state": "AMBIGUOUS",
                "mode": request["mode"],
                "operation_id": request["operation_id"],
                "request_id": request_id,
                "project_id": request["project_id"],
                "route_name": request["route_name"],
                "destination_folder_id": recovery_route["folder_id"],
                "drive_identity": recovery_route["verification"]["drive_identity"],
                "connector_call_count": stored["connector_call_count"],
                "error": error,
                "retry_allowed": False,
                "replay_allowed": False,
            }
            return self.store.recover_dispatching_as_ambiguous(
                request["operation_id"], recovery, error
            )
        project = self.store.show_project(request["project_id"])
        if project["enabled"] != 1:
            raise HubError("HUB_UNBOUND")
        if project["project_identity"] != request["project_identity"]:
            raise HubError("PROJECT_ROOT_MISMATCH")
        route = self.store.show_route(request["project_id"], request["route_name"])
        drive_identity = route["verification"]["drive_identity"]
        manifest, bodies = _parse_frame(request, frame_bytes)
        max_items = getattr(self.connector, "max_items_per_operation", None)
        if max_items is not None and len(manifest["files"]) > max_items:
            raise HubError("MULTI_ITEM_REQUEST")
        now = _utc_now()
        try:
            with self.store._connect() as connection:
                # Claim atomically against the new recovery schema as well.
                # Existing v1 receipts/ambiguous records retain their behavior.
                connection.execute("BEGIN IMMEDIATE")
                if connection.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='material_recovery_v1'").fetchone():
                    if connection.execute("SELECT 1 FROM material_recovery_v1 WHERE operation_id=?", (request["operation_id"],)).fetchone():
                        raise HubError("OPERATION_ID_CONFLICT")
                connection.execute(
                    "INSERT INTO operations VALUES (?, ?, ?, ?, 'DISPATCHING', 0, NULL, NULL, ?, NULL)",
                    (
                        request["operation_id"],
                        request_sha256,
                        request["project_id"],
                        request["route_name"],
                        now,
                    ),
                )
                for index, record in enumerate(manifest["files"]):
                    connection.execute(
                        "INSERT INTO operation_items "
                        "(operation_id, item_index, source_path, byte_size, "
                        "source_sha256, state, dispatch_attempt_count, "
                        "remote_file_id, remote_revision, connector_result_json, "
                        "error_json) VALUES (?, ?, ?, ?, ?, 'PENDING', 0, NULL, "
                        "NULL, NULL, NULL)",
                        (
                            request["operation_id"],
                            index,
                            record["path"],
                            record["byte_size"],
                            record["sha256"],
                        ),
                    )
        except sqlite3.IntegrityError as error:
            raise HubError("OPERATION_ID_CONFLICT") from error

        if request["mode"] == "preflight":
            revision = "local-preflight-" + request_sha256[:16]
            receipt = {
                "schema_version": "drive-exchange-local-receipt-v1",
                "operation_id": request["operation_id"],
                "request_id": request_id,
                "revision": revision,
                "project_id": request["project_id"],
                "route_name": request["route_name"],
                "mode": "preflight",
                "destination_folder_id": route["folder_id"],
                "drive_identity": drive_identity,
                "manifest_sha256": request["manifest_sha256"],
                "frame_sha256": request["frame_sha256"],
                "remote_files": [],
            }
            receipt_bytes = canonical_json_bytes(receipt)
            result = {
                "schema_version": "drive-exchange-local-hub-result-v1",
                "state": "SUCCEEDED",
                "mode": "preflight",
                "operation_id": request["operation_id"],
                "request_id": request_id,
                "revision": revision,
                "project_id": request["project_id"],
                "route_name": request["route_name"],
                "destination_folder_id": route["folder_id"],
                "drive_identity": drive_identity,
                "connector_call_count": 0,
                "files": [],
                "receipt": receipt,
                "receipt_sha256": hashlib.sha256(receipt_bytes).hexdigest(),
            }
            result_bytes = canonical_json_bytes(result)
            with self.store._connect() as connection:
                connection.execute(
                    "INSERT INTO receipts VALUES (?, ?, ?, ?)",
                    (
                        request["operation_id"],
                        receipt_bytes,
                        len(receipt_bytes),
                        result["receipt_sha256"],
                    ),
                )
                connection.execute(
                    "UPDATE operations SET state='SUCCEEDED', result_json=?, completed_at=? WHERE operation_id=?",
                    (result_bytes, _utc_now(), request["operation_id"]),
                )
            return result

        remote_files = []
        for index, (record, body) in enumerate(zip(manifest["files"], bodies)):
            with self.store._connect() as connection:
                connection.execute("BEGIN IMMEDIATE")
                item = connection.execute(
                    "UPDATE operation_items SET state='DISPATCHING', "
                    "dispatch_attempt_count=dispatch_attempt_count+1 "
                    "WHERE operation_id=? AND item_index=? AND state='PENDING'",
                    (request["operation_id"], index),
                )
                if item.rowcount != 1:
                    raise HubError("OPERATION_STATE_INVALID")
                connection.execute(
                    "UPDATE operations SET "
                    "connector_call_count=connector_call_count+1 "
                    "WHERE operation_id=? AND state='DISPATCHING'",
                    (request["operation_id"],),
                )
            try:
                connector_result = self.connector.upload(
                    folder_id=route["folder_id"],
                    expected_drive_identity=drive_identity,
                    source_path=record["path"],
                    body=body,
                    operation_id=request["operation_id"],
                )
                remote = {
                    "path": record["path"],
                    "byte_size": record["byte_size"],
                    "source_sha256": record["sha256"],
                    "remote_file_id": connector_result["remote_file_id"],
                    "revision": connector_result["revision"],
                }
                connector_result_bytes = canonical_json_bytes(connector_result)
                canonical_json_bytes(remote)
                with self.store._connect() as connection:
                    item = connection.execute(
                        "UPDATE operation_items SET state='SUCCEEDED', "
                        "remote_file_id=?, remote_revision=?, "
                        "connector_result_json=? WHERE operation_id=? AND "
                        "item_index=? AND state='DISPATCHING'",
                        (
                            remote["remote_file_id"],
                            remote["revision"],
                            connector_result_bytes,
                            request["operation_id"],
                            index,
                        ),
                    )
                    if item.rowcount != 1:
                        raise HubError("OPERATION_STATE_INVALID")
            except ConnectorDefinitiveError as error:
                try:
                    return self._close_issued_attempt(
                        request=request,
                        request_id=request_id,
                        route=route,
                        drive_identity=drive_identity,
                        item_index=index,
                        state="DEFINITIVE_FAILURE",
                        error=_closed_connector_error(error.error),
                    )
                except Exception:
                    return self._close_unresolved_issued_attempt(
                        request=request,
                        request_id=request_id,
                        route=route,
                        drive_identity=drive_identity,
                        item_index=index,
                    )
            except ConnectorAmbiguousError as error:
                try:
                    return self._close_issued_attempt(
                        request=request,
                        request_id=request_id,
                        route=route,
                        drive_identity=drive_identity,
                        item_index=index,
                        state="AMBIGUOUS",
                        error=_closed_connector_error(error.error),
                    )
                except Exception:
                    return self._close_unresolved_issued_attempt(
                        request=request,
                        request_id=request_id,
                        route=route,
                        drive_identity=drive_identity,
                        item_index=index,
                    )
            except Exception:
                return self._close_unresolved_issued_attempt(
                    request=request,
                    request_id=request_id,
                    route=route,
                    drive_identity=drive_identity,
                    item_index=index,
                )
            remote_files.append(remote)

        operation_revision = "local-rev-" + request_sha256[:16]
        receipt = {
            "schema_version": "drive-exchange-local-receipt-v1",
            "operation_id": request["operation_id"],
            "request_id": request_id,
            "revision": operation_revision,
            "project_id": request["project_id"],
            "route_name": request["route_name"],
            "mode": request["mode"],
            "destination_folder_id": route["folder_id"],
            "drive_identity": drive_identity,
            "manifest_sha256": request["manifest_sha256"],
            "frame_sha256": request["frame_sha256"],
            "remote_files": remote_files,
        }
        receipt_bytes = canonical_json_bytes(receipt)
        result = {
            "schema_version": "drive-exchange-local-hub-result-v1",
            "state": "SUCCEEDED",
            "mode": request["mode"],
            "operation_id": request["operation_id"],
            "request_id": request_id,
            "revision": operation_revision,
            "project_id": request["project_id"],
            "route_name": request["route_name"],
            "destination_folder_id": route["folder_id"],
            "drive_identity": drive_identity,
            "connector_call_count": len(remote_files),
            "files": remote_files,
            "receipt": receipt,
            "receipt_sha256": hashlib.sha256(receipt_bytes).hexdigest(),
        }
        result_bytes = canonical_json_bytes(result)
        with self.store._connect() as connection:
            connection.execute(
                "INSERT INTO receipts VALUES (?, ?, ?, ?)",
                (
                    request["operation_id"],
                    receipt_bytes,
                    len(receipt_bytes),
                    result["receipt_sha256"],
                ),
            )
            connection.execute(
                "UPDATE operations SET state='SUCCEEDED', result_json=?, completed_at=? WHERE operation_id=?",
                (result_bytes, _utc_now(), request["operation_id"]),
            )
        return result


__all__ = [
    "ConnectorAmbiguousError",
    "ConnectorDefinitiveError",
    "FakeDriveConnector",
    "HubError",
    "HubStore",
    "LocalHub",
    "canonical_json_bytes",
    "project_identity_for_root",
]
