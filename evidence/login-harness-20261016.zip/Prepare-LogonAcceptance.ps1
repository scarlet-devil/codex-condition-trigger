param([ValidateSet('Arm','Verify','Stop')][string]$Action='Verify')
$ErrorActionPreference='Stop'
$taskName='Codex-ConditionTrigger-DryAcceptance-20261016'
$testRoot=Join-Path $PSScriptRoot 'logon-dry'
$configPath=Join-Path $testRoot 'config.json'
$statePath=Join-Path $testRoot 'state'
$pythonPath='D:\新skill试运行\dot-results-monitor\runs\20261003T133248Z-trigger-windows-acceptance\.venv\Scripts\python.exe'
$pythonwPath='D:\新skill试运行\dot-results-monitor\runs\20261003T133248Z-trigger-windows-acceptance\.venv\Scripts\pythonw.exe'
$wrapper=Join-Path $PSScriptRoot 'logon_acceptance.py'
if($Action -eq 'Arm'){
    if(Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue){throw 'Exact acceptance task already exists; do not replace it.'}
    if(Test-Path -LiteralPath $configPath){throw 'Original fixed deadline must be retained.'}
    New-Item -ItemType Directory -Path (Join-Path $testRoot 'input') -Force | Out-Null
    New-Item -ItemType Directory -Path $statePath -Force | Out-Null
    $deadline=[DateTimeOffset]::UtcNow.AddMinutes(15)
    $c=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'candidate\example.windows.json') -Raw | ConvertFrom-Json
    $c.input_dir=Join-Path $testRoot 'input';$c.state_dir=$statePath;$c.expected_cwd=$testRoot
    $c.settle_seconds=1;$c.rescan_seconds=2
    $c | Add-Member -NotePropertyName trial_expires_at_utc -NotePropertyValue $deadline.ToString('o')
    $c | ConvertTo-Json -Depth 10 | Set-Content -LiteralPath $configPath -Encoding utf8
    'Synthetic login acceptance only; no model, upload or ACK.' | Set-Content -LiteralPath (Join-Path $testRoot 'input\probe.txt') -Encoding utf8
    $pins=@{}
    foreach($name in @('trial_worker.py','trigger.py','owner_loading.py','desktop_ipc.py','chat_adapters.py','trial_limits.py','worker_health.py','execution_result.py','delivery_outbox.py','native_collector.py')){
        $pins[$name]=(Get-FileHash -LiteralPath (Join-Path $PSScriptRoot ('candidate\'+$name)) -Algorithm SHA256).Hash.ToLowerInvariant()
    }
    $pins['logon_acceptance.py']=(Get-FileHash -LiteralPath $wrapper -Algorithm SHA256).Hash.ToLowerInvariant()
    $pins | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $testRoot 'source-pins.json') -Encoding utf8
    & $pythonPath -X utf8 -B $wrapper --snapshot (Join-Path $testRoot 'before-login.private.json')
    if($LASTEXITCODE -ne 0){throw 'Cannot capture current logon identity.'}
    $user=[System.Security.Principal.WindowsIdentity]::GetCurrent().Name
    $nativeAction=New-ScheduledTaskAction -Execute $pythonwPath -Argument ('-X utf8 -B "'+$wrapper+'" "'+$configPath+'"') -WorkingDirectory $PSScriptRoot
    $trigger=New-ScheduledTaskTrigger -AtLogOn -User $user
    $trigger.EndBoundary=$deadline.LocalDateTime.ToString('s')
    $principal=New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
    $settings=New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 5) -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
    Register-ScheduledTask -TaskName $taskName -Action $nativeAction -Trigger $trigger -Principal $principal -Settings $settings | Out-Null
    Export-ScheduledTask -TaskName $taskName | Set-Content -LiteralPath (Join-Path $testRoot 'registered-task.private.xml') -Encoding utf8
    $receipt=@{armed_at_utc=[DateTimeOffset]::UtcNow.ToString('o');deadline_utc=$deadline.ToString('o');deadline_local=$deadline.LocalDateTime.ToString('yyyy-MM-dd HH:mm:ss');mode='dry';task=$taskName;manual_start_calls=0;logoff_calls=0;task_scheduler_operational_log='disabled_unmodified'}
    $receipt | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $testRoot 'arm-receipt.json') -Encoding utf8
    $receipt | ConvertTo-Json
}elseif($Action -eq 'Stop'){
    if(Test-Path -LiteralPath $statePath){New-Item -ItemType File -Path (Join-Path $statePath 'STOP') -Force | Out-Null}
    if(Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue){Disable-ScheduledTask -TaskName $taskName | Out-Null}
    'Dedicated dry login acceptance disabled; all evidence retained.'
}else{
    $task=Get-ScheduledTask -TaskName $taskName -ErrorAction SilentlyContinue
    if(!$task){'Not armed.';exit 0}
    Get-ScheduledTaskInfo -TaskName $taskName | Select-Object LastRunTime,LastTaskResult,NextRunTime | ConvertTo-Json
    foreach($name in @('login-start.private.json','login-exit.private.json','latest-worker.json')){
        $p=Join-Path $statePath $name
        if(Test-Path -LiteralPath $p){Get-Content -LiteralPath $p -Raw}
    }
    'Acceptance requires Human actual-login confirmation plus changed logon SID and exact task/worker evidence. Task event log is disabled; no trigger-event evidence is claimed.'
}
