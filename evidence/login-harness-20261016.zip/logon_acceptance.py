"""Dedicated dry login harness. No network, model, Hub or production state."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,re,subprocess,sys
ROOT=Path(__file__).parent

def context():
    p=subprocess.run(['whoami.exe','/logonid'],capture_output=True,check=True,
        creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
    ids=re.findall(rb'S-1-5-5-\d+-\d+',p.stdout)
    if len(ids)!=1:raise ValueError('logon identity unavailable')
    return dict(at_utc=datetime.now(timezone.utc).isoformat(),pid=os.getpid(),parent_pid=os.getppid(),
                logon_sid=ids[0].decode('ascii'))

if __name__=='__main__':
    if sys.argv[1]=='--snapshot':
        Path(sys.argv[2]).write_text(json.dumps(context(),indent=2),encoding='utf-8')
    else:
        config=Path(sys.argv[1]);state=config.parent/'state'
        sys.path.insert(0,str(ROOT/'candidate'))
        expected=json.loads((config.parent/'source-pins.json').read_bytes())
        for name,digest in expected.items():
            path=ROOT/'logon_acceptance.py' if name=='logon_acceptance.py' else ROOT/'candidate'/name
            if hashlib.sha256(path.read_bytes()).hexdigest()!=digest:raise ValueError('source changed')
        proof=dict(context(),config_sha256=hashlib.sha256(config.read_bytes()).hexdigest(),
                   mode='dry',source_pins=expected,manual_start_calls=0)
        (state/'login-start.private.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
        import trial_worker
        code=trial_worker.run_bounded(config,live=False)
        proof.update(exit_code=code,exited_at_utc=datetime.now(timezone.utc).isoformat())
        (state/'login-exit.private.json').write_text(json.dumps(proof,indent=2),encoding='utf-8')
        raise SystemExit(code)
